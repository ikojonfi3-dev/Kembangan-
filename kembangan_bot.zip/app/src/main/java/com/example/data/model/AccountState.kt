package com.example.data.model

data class AccountState(
    val initialBalance: Double = 10000.0,
    val balance: Double = 10000.0,
    val equity: Double = 10000.0,
    val usedMargin: Double = 0.0,
    val leverage: Int = 100, // 1:100 leverage
    val currency: String = "USD"
) {
    val floatingPnL: Double get() = equity - balance
    val freeMargin: Double get() = kotlin.math.max(0.0, equity - usedMargin)
    val marginLevel: Double get() = if (usedMargin > 0) (equity / usedMargin) * 100.0 else 9999.0
    val totalProfitPercent: Double get() = ((equity - initialBalance) / initialBalance) * 100.0
}

data class PerformanceMetrics(
    val totalTrades: Int = 0,
    val winningTrades: Int = 0,
    val losingTrades: Int = 0,
    val winRate: Double = 0.0,
    val totalProfitLoss: Double = 0.0,
    val profitFactor: Double = 0.0,
    val bestTrade: Double = 0.0,
    val worstTrade: Double = 0.0,
    val averageTrade: Double = 0.0,
    val maxDrawdownPercent: Double = 0.0
)
