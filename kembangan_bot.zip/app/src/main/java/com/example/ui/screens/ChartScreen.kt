package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.OrderType
import com.example.data.model.ForexPair
import com.example.data.model.TimeFrame
import com.example.ui.components.AiAnalysisDialog
import com.example.ui.components.CandlestickChart
import com.example.ui.components.PairTickerBar
import com.example.ui.components.TradeDialog
import com.example.ui.theme.BearishCandle
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BullishCandle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.PurpleAi
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.ForexViewModel

@Composable
fun ChartScreen(
    viewModel: ForexViewModel,
    modifier: Modifier = Modifier
) {
    val pairs by viewModel.pairs.collectAsState()
    val selectedPair by viewModel.selectedPair.collectAsState()
    val selectedTimeFrame by viewModel.selectedTimeFrame.collectAsState()
    val currentCandles by viewModel.currentCandles.collectAsState()
    val aiScanResult by viewModel.aiScanResult.collectAsState()

    var showIndicators by remember { mutableStateOf(true) }
    var showTradeDialog by remember { mutableStateOf(false) }
    var orderType by remember { mutableStateOf(OrderType.BUY) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Top Pair Selector Bar
        PairTickerBar(
            pairs = pairs,
            selectedPair = selectedPair,
            onPairSelected = { viewModel.selectPair(it) }
        )

        // Pair Header Details & Live Quotes
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            selectedPair.symbol,
                            color = TextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            selectedPair.name,
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                    Text(
                        "24h High: ${selectedPair.high24h} | Low: ${selectedPair.low24h} | Spread: ${String.format("%.1f", selectedPair.spread)} pips",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }

                Button(
                    onClick = { viewModel.scanWithGeminiAI(selectedPair) },
                    colors = ButtonDefaults.buttonColors(containerColor = PurpleAi),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("chart_gemini_scan_button")
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("AI Scan", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Timeframe Selector & Indicators Toggle
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                TimeFrame.entries.forEach { tf ->
                    val isSelected = tf == selectedTimeFrame
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) CyanAccent else DarkSurfaceElevated)
                            .clickable { viewModel.selectTimeFrame(tf) }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = tf.label,
                            color = if (isSelected) Color.Black else TextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (showIndicators) DarkSurfaceElevated else DarkSurface)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(6.dp))
                    .clickable { showIndicators = !showIndicators }
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(Icons.Default.Layers, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(14.dp))
                    Text(
                        if (showIndicators) "Indikator ON" else "Indikator OFF",
                        color = TextPrimary,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Main Candlestick Chart
        CandlestickChart(
            candles = currentCandles,
            decimals = selectedPair.decimals,
            showIndicators = showIndicators,
            modifier = Modifier.fillMaxWidth()
        )

        // Live Order Execution Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = {
                    orderType = OrderType.BUY
                    showTradeDialog = true
                },
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("chart_screen_buy_button"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = BullishCandle,
                    contentColor = Color.Black
                )
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("BUY (ASK)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(selectedPair.formattedAsk, fontSize = 11.sp)
                }
            }

            Button(
                onClick = {
                    orderType = OrderType.SELL
                    showTradeDialog = true
                },
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("chart_screen_sell_button"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = BearishCandle,
                    contentColor = Color.White
                )
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("SELL (BID)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(selectedPair.formattedPrice, fontSize = 11.sp)
                }
            }
        }
    }

    if (showTradeDialog) {
        TradeDialog(
            pair = selectedPair,
            initialOrderType = orderType,
            onDismiss = { showTradeDialog = false },
            onExecuteTrade = { type, lot, sl, tp ->
                viewModel.placeOrder(type, lot, sl, tp)
            }
        )
    }

    aiScanResult?.let { scan ->
        AiAnalysisDialog(scanResult = scan, onDismiss = { viewModel.clearAiScan() })
    }
}
