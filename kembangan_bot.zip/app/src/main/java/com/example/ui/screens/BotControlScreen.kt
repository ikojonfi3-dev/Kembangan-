package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.BotLogEntity
import com.example.data.model.BotStrategyConfig
import com.example.data.model.ForexPair
import com.example.data.model.StrategyType
import com.example.domain.engine.BacktestResult
import com.example.domain.engine.Mql5Generator
import com.example.domain.engine.Mt5Config
import com.example.ui.components.BotStatusCard
import com.example.ui.theme.BearishCandle
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BullishCandle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.PurpleAi
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.ForexViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun BotControlScreen(
    viewModel: ForexViewModel,
    modifier: Modifier = Modifier
) {
    val strategyConfig by viewModel.strategyConfig.collectAsState()
    val accountState by viewModel.accountState.collectAsState()
    val botLogs by viewModel.botLogs.collectAsState()
    val pairs by viewModel.pairs.collectAsState()
    val selectedPair by viewModel.selectedPair.collectAsState()
    val backtestResult by viewModel.backtestResult.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Strategi, 1: MT5 EA, 2: Backtest, 3: Log

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
    ) {
        // Tab Header
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            containerColor = DarkSurface,
            contentColor = CyanAccent,
            edgePadding = 8.dp,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = CyanAccent
                )
            }
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Strategi Bot", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                icon = { Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(16.dp)) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Manajemen Risiko", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = if (selectedTab == 1) CyanAccent else TextSecondary) },
                icon = { Icon(Icons.Default.Shield, contentDescription = null, tint = if (selectedTab == 1) CyanAccent else TextSecondary, modifier = Modifier.size(16.dp)) }
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text("MT5 & Gold EA", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = if (selectedTab == 2) GoldAccent else TextSecondary) },
                icon = { Icon(Icons.Default.Code, contentDescription = null, tint = if (selectedTab == 2) GoldAccent else TextSecondary, modifier = Modifier.size(16.dp)) }
            )
            Tab(
                selected = selectedTab == 3,
                onClick = { selectedTab = 3 },
                text = { Text("Backtest AI", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                icon = { Icon(Icons.Default.Assessment, contentDescription = null, modifier = Modifier.size(16.dp)) }
            )
            Tab(
                selected = selectedTab == 4,
                onClick = { selectedTab = 4 },
                text = { Text("Log Bot (${botLogs.size})", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                icon = { Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(16.dp)) }
            )
        }

        when (selectedTab) {
            0 -> BotStrategiesTab(
                config = strategyConfig,
                accountState = accountState,
                onUpdateConfig = { viewModel.updateStrategyConfig(it) },
                onToggleAutoTrade = { viewModel.toggleAutoTrading(it) },
                onOpenRiskPanel = { selectedTab = 1 }
            )
            1 -> RiskManagementTab(
                config = strategyConfig,
                accountState = accountState,
                pairs = pairs,
                onUpdateConfig = { viewModel.updateStrategyConfig(it) },
                onTestNotification = { viewModel.triggerTestSignalNotification() }
            )
            2 -> Mt5IntegrationTab(
                pairs = pairs,
                selectedPair = selectedPair
            )
            3 -> BacktestTab(
                pairs = pairs,
                selectedPair = selectedPair,
                backtestResult = backtestResult,
                onRunBacktest = { pair, strat, lot ->
                    viewModel.runBacktest(pair, strat, lot)
                }
            )
            4 -> BotLogsTab(logs = botLogs)
        }
    }
}

@Composable
fun BotStrategiesTab(
    config: BotStrategyConfig,
    accountState: com.example.data.model.AccountState,
    onUpdateConfig: (BotStrategyConfig) -> Unit,
    onToggleAutoTrade: (Boolean) -> Unit,
    onOpenRiskPanel: () -> Unit = {}
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            BotStatusCard(
                config = config,
                accountState = accountState,
                onToggleAutoTrade = onToggleAutoTrade
            )
        }

        // Quick Risk Management Summary Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onOpenRiskPanel() },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyanAccent.copy(alpha = 0.4f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Shield, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(18.dp))
                            Text("Pengaturan Manajemen Risiko", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(CyanAccent.copy(alpha = 0.15f))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text("Buka Panel Lengkap >", color = CyanAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Lot Per Trade", color = TextSecondary, fontSize = 11.sp)
                            Text("${String.format("%.2f", config.lotSize)} Lot", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("Max Drawdown", color = TextSecondary, fontSize = 11.sp)
                            Text("${String.format("%.1f", config.maxDrawdownPercent)}%", color = BearishCandle, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("SL / TP", color = TextSecondary, fontSize = 11.sp)
                            Text("${config.stopLossPips.toInt()} / ${config.takeProfitPips.toInt()} Pips", color = GoldAccent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("Max Posisi", color = TextSecondary, fontSize = 11.sp)
                            Text("${config.maxOpenTrades} Trade", color = CyanAccent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            Text(
                "Pilih Algoritma Strategi AI",
                color = TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
        }

        items(StrategyType.entries) { strategy ->
            val isSelected = config.strategyType == strategy
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .clickable {
                        onUpdateConfig(config.copy(strategyType = strategy))
                    },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) DarkSurfaceElevated else DarkSurface
                ),
                border = androidx.compose.foundation.BorderStroke(
                    width = if (isSelected) 1.5.dp else 1.dp,
                    color = if (isSelected) CyanAccent else BorderSubtle
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                strategy.title,
                                color = TextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(CyanAccent.copy(alpha = 0.15f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(strategy.badge, color = CyanAccent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Text(
                            text = when (strategy) {
                                StrategyType.TREND_MOMENTUM -> "Mengikuti tren pasar menggunakan persilangan EMA 20/50 dan filter momentum RSI."
                                StrategyType.BREAKOUT_SCALPER -> "Mendeteksi lonjakan volume dan penembusan batas luar Bollinger Bands."
                                StrategyType.SMC_ORDER_BLOCK -> "Smart Money Concepts: Mengidentifikasi zona order block institusi dan sweep likuiditas."
                                StrategyType.RSI_MEAN_REVERSION -> "Membeli saat over-sold (<30) dan menjual saat over-bought (>70) dengan konfirmasi candle."
                                StrategyType.MULTI_CONFIRMATION_HYBRID -> "Kombinasi triple multi-timeframe didukung reasoning AI Gemini."
                            },
                            color = TextSecondary,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    }

                    if (isSelected) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = CyanAccent,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun RiskManagementTab(
    config: BotStrategyConfig,
    accountState: com.example.data.model.AccountState,
    pairs: List<ForexPair>,
    onUpdateConfig: (BotStrategyConfig) -> Unit,
    onTestNotification: () -> Unit
) {
    val peakBalance = kotlin.math.max(accountState.initialBalance, accountState.balance)
    val currentDrawdown = if (peakBalance > 0.0 && accountState.equity < peakBalance) {
        ((peakBalance - accountState.equity) / peakBalance) * 100.0
    } else 0.0

    val isCircuitTripped = config.circuitBreakerTriggered || currentDrawdown >= config.maxDrawdownPercent

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Live Circuit Breaker & Safety Status Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isCircuitTripped) Color(0xFF2D1515) else DarkSurface
                ),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isCircuitTripped) BearishCandle else CyanAccent.copy(alpha = 0.5f)
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isCircuitTripped) BearishCandle else CyanAccent),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (isCircuitTripped) Icons.Default.Warning else Icons.Default.Shield,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Column {
                                Text(
                                    "Safety Circuit Breaker",
                                    color = TextPrimary,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    if (isCircuitTripped) "TRIPPED - AUTO TRADING DIHENTIKAN" else "STATUS AKTIF & MEMANTAU AKUN",
                                    color = if (isCircuitTripped) BearishCandle else BullishCandle,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        if (isCircuitTripped) {
                            Button(
                                onClick = {
                                    onUpdateConfig(config.copy(circuitBreakerTriggered = false))
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = BearishCandle, contentColor = Color.White),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Reset Guard", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Drawdown Progress Meter
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Current Account Drawdown", color = TextSecondary, fontSize = 11.sp)
                            Text(
                                "${String.format("%.1f", currentDrawdown)}% / Max ${String.format("%.1f", config.maxDrawdownPercent)}%",
                                color = if (currentDrawdown >= config.maxDrawdownPercent * 0.8) BearishCandle else TextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        val progress = (currentDrawdown / config.maxDrawdownPercent).coerceIn(0.0, 1.0).toFloat()
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = if (progress >= 0.8f) BearishCandle else if (progress >= 0.5f) GoldAccent else CyanAccent,
                            trackColor = DarkSurfaceElevated,
                        )
                    }

                    Text(
                        "Jika drawdown atau penurunan ekuitas akun menyentuh batas maksimum (${String.format("%.1f", config.maxDrawdownPercent)}%), bot akan memutus order otomatis seketika guna melindungi modal trading Anda.",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
            }
        }

        // 2. Quick Profile Presets
        item {
            Text(
                "Pilihan Profil Risiko Cepat:",
                color = TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Low Risk
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable {
                            onUpdateConfig(
                                config.copy(
                                    lotSize = 0.01,
                                    maxDrawdownPercent = 5.0,
                                    maxDailyLossPercent = 3.0,
                                    stopLossPips = 20.0,
                                    takeProfitPips = 40.0,
                                    maxOpenTrades = 2,
                                    minConfidenceThreshold = 80
                                )
                            )
                        },
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("🛡️ Rendah", color = BullishCandle, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("0.01 Lot | 5% DD", color = TextSecondary, fontSize = 10.sp)
                    }
                }

                // Moderate
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable {
                            onUpdateConfig(
                                config.copy(
                                    lotSize = 0.10,
                                    maxDrawdownPercent = 10.0,
                                    maxDailyLossPercent = 5.0,
                                    stopLossPips = 25.0,
                                    takeProfitPips = 50.0,
                                    maxOpenTrades = 3,
                                    minConfidenceThreshold = 75
                                )
                            )
                        },
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyanAccent.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("⚖️ Moderat", color = CyanAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("0.10 Lot | 10% DD", color = TextSecondary, fontSize = 10.sp)
                    }
                }

                // Aggressive
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable {
                            onUpdateConfig(
                                config.copy(
                                    lotSize = 0.25,
                                    maxDrawdownPercent = 20.0,
                                    maxDailyLossPercent = 10.0,
                                    stopLossPips = 35.0,
                                    takeProfitPips = 70.0,
                                    maxOpenTrades = 5,
                                    minConfidenceThreshold = 70
                                )
                            )
                        },
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("⚡ Agresif", color = GoldAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("0.25 Lot | 20% DD", color = TextSecondary, fontSize = 10.sp)
                    }
                }
            }
        }

        // 3. Lot Size Configuration Panel
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Ukuran Lot per Transaksi (Lot Size)", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("Volume trading yang dibuka bot pada setiap order", color = TextSecondary, fontSize = 11.sp)
                        }

                        // Stepper Box
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            IconButton(
                                onClick = {
                                    val newLot = (config.lotSize - 0.01).coerceAtLeast(0.01)
                                    onUpdateConfig(config.copy(lotSize = (Math.round(newLot * 100.0) / 100.0)))
                                },
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(DarkSurfaceElevated)
                            ) {
                                Icon(Icons.Default.Remove, contentDescription = null, tint = TextPrimary, modifier = Modifier.size(16.dp))
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(CyanAccent.copy(alpha = 0.15f))
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    "${String.format("%.2f", config.lotSize)} Lot",
                                    color = CyanAccent,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            IconButton(
                                onClick = {
                                    val newLot = (config.lotSize + 0.01).coerceAtMost(2.00)
                                    onUpdateConfig(config.copy(lotSize = (Math.round(newLot * 100.0) / 100.0)))
                                },
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(DarkSurfaceElevated)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, tint = TextPrimary, modifier = Modifier.size(16.dp))
                            }
                        }
                    }

                    Slider(
                        value = config.lotSize.toFloat(),
                        onValueChange = {
                            onUpdateConfig(config.copy(lotSize = (Math.round(it * 100.0) / 100.0)))
                        },
                        valueRange = 0.01f..2.00f,
                        steps = 199,
                        colors = SliderDefaults.colors(thumbColor = CyanAccent, activeTrackColor = CyanAccent)
                    )

                    // Lot Quick Chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(0.01, 0.05, 0.10, 0.25, 0.50, 1.00).forEach { lotValue ->
                            val isSelected = Math.abs(config.lotSize - lotValue) < 0.005
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSelected) CyanAccent else DarkSurfaceElevated)
                                    .border(1.dp, if (isSelected) CyanAccent else BorderSubtle, RoundedCornerShape(6.dp))
                                    .clickable { onUpdateConfig(config.copy(lotSize = lotValue)) }
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    String.format("%.2f", lotValue),
                                    color = if (isSelected) Color.Black else TextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Margin & Pip Value Calculation Box
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(DarkBg)
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Estimasi Margin Terpakai", color = TextSecondary, fontSize = 10.sp)
                            Text(
                                "~$${String.format("%.1f", config.lotSize * 1000.0)} USD (Lev 1:100)",
                                color = TextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Nilai Per Pip (EUR/USD)", color = TextSecondary, fontSize = 10.sp)
                            Text(
                                "~$${String.format("%.2f", config.lotSize * 10.0)} USD / Pip",
                                color = BullishCandle,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        // 4. Maximum Drawdown & Daily Loss Limit Panel
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Max Drawdown Slider
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Batas Maksimum Drawdown (Circuit Breaker)", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text("Toleransi penurunan ekuitas sebelum bot berhenti", color = TextSecondary, fontSize = 11.sp)
                            }
                            Text(
                                "${String.format("%.1f", config.maxDrawdownPercent)}%",
                                color = BearishCandle,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Slider(
                            value = config.maxDrawdownPercent.toFloat(),
                            onValueChange = {
                                onUpdateConfig(config.copy(maxDrawdownPercent = (Math.round(it * 10.0) / 10.0)))
                            },
                            valueRange = 3.0f..30.0f,
                            steps = 27,
                            colors = SliderDefaults.colors(thumbColor = BearishCandle, activeTrackColor = BearishCandle)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(5.0, 10.0, 15.0, 20.0).forEach { dd ->
                                val isSelected = Math.abs(config.maxDrawdownPercent - dd) < 0.1
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isSelected) BearishCandle else DarkSurfaceElevated)
                                        .clickable { onUpdateConfig(config.copy(maxDrawdownPercent = dd)) }
                                        .padding(vertical = 4.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        "${dd.toInt()}%",
                                        color = if (isSelected) Color.White else TextPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    // Max Daily Loss Slider
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Batas Kerugian Harian (Max Daily Loss)", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text("${String.format("%.1f", config.maxDailyLossPercent)}%", color = GoldAccent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = config.maxDailyLossPercent.toFloat(),
                            onValueChange = {
                                onUpdateConfig(config.copy(maxDailyLossPercent = (Math.round(it * 10.0) / 10.0)))
                            },
                            valueRange = 1.0f..15.0f,
                            steps = 14,
                            colors = SliderDefaults.colors(thumbColor = GoldAccent, activeTrackColor = GoldAccent)
                        )
                    }
                }
            }
        }

        // 5. Stop Loss & Take Profit Preferences
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        "Parameter Stop Loss & Take Profit",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )

                    // SL Slider
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Stop Loss (SL)", color = TextSecondary, fontSize = 12.sp)
                            Text("${config.stopLossPips.toInt()} Pips", color = BearishCandle, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = config.stopLossPips.toFloat(),
                            onValueChange = { onUpdateConfig(config.copy(stopLossPips = it.toDouble())) },
                            valueRange = 10f..100f,
                            colors = SliderDefaults.colors(thumbColor = BearishCandle, activeTrackColor = BearishCandle)
                        )
                    }

                    // TP Slider
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Take Profit (TP)", color = TextSecondary, fontSize = 12.sp)
                            Text("${config.takeProfitPips.toInt()} Pips", color = BullishCandle, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = config.takeProfitPips.toFloat(),
                            onValueChange = { onUpdateConfig(config.copy(takeProfitPips = it.toDouble())) },
                            valueRange = 20f..200f,
                            colors = SliderDefaults.colors(thumbColor = BullishCandle, activeTrackColor = BullishCandle)
                        )
                    }

                    // Quick Risk-Reward Presets
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("R:R Ratio:", color = TextSecondary, fontSize = 11.sp)
                        listOf(1.0, 1.5, 2.0, 3.0).forEach { ratio ->
                            val isMatch = Math.abs((config.takeProfitPips / config.stopLossPips) - ratio) < 0.1
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isMatch) CyanAccent else DarkSurfaceElevated)
                                    .clickable {
                                        onUpdateConfig(config.copy(takeProfitPips = config.stopLossPips * ratio))
                                    }
                                    .padding(vertical = 4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    "1:${if (ratio == 1.5) "1.5" else ratio.toInt().toString()}",
                                    color = if (isMatch) Color.Black else TextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Trailing Stop Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Trailing Stop Otomatis", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text("Geser SL naik untuk kunci profit (${config.trailingStopPips.toInt()} pips)", color = TextSecondary, fontSize = 10.sp)
                        }
                        Switch(
                            checked = config.useTrailingStop,
                            onCheckedChange = { onUpdateConfig(config.copy(useTrailingStop = it)) },
                            colors = SwitchDefaults.colors(checkedTrackColor = CyanAccent)
                        )
                    }
                }
            }
        }

        // 6. Max Concurrent Trades & Confidence Filter
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Max Open Trades
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Maksimum Transaksi Terbuka", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text("Batas order aktif berjalan bersamaan", color = TextSecondary, fontSize = 10.sp)
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            IconButton(
                                onClick = {
                                    val newMax = (config.maxOpenTrades - 1).coerceAtLeast(1)
                                    onUpdateConfig(config.copy(maxOpenTrades = newMax))
                                },
                                modifier = Modifier.size(28.dp).clip(RoundedCornerShape(4.dp)).background(DarkSurfaceElevated)
                            ) {
                                Icon(Icons.Default.Remove, contentDescription = null, tint = TextPrimary, modifier = Modifier.size(14.dp))
                            }
                            Text("${config.maxOpenTrades}", color = CyanAccent, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 8.dp))
                            IconButton(
                                onClick = {
                                    val newMax = (config.maxOpenTrades + 1).coerceAtMost(8)
                                    onUpdateConfig(config.copy(maxOpenTrades = newMax))
                                },
                                modifier = Modifier.size(28.dp).clip(RoundedCornerShape(4.dp)).background(DarkSurfaceElevated)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, tint = TextPrimary, modifier = Modifier.size(14.dp))
                            }
                        }
                    }

                    // Confidence threshold
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Ambang Keyakinan Sinyal AI", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text("≥ ${config.minConfidenceThreshold}%", color = CyanAccent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = config.minConfidenceThreshold.toFloat(),
                            onValueChange = { onUpdateConfig(config.copy(minConfidenceThreshold = it.toInt())) },
                            valueRange = 60f..90f,
                            steps = 6,
                            colors = SliderDefaults.colors(thumbColor = CyanAccent, activeTrackColor = CyanAccent)
                        )
                    }
                }
            }
        }

        // 7. Pair Allocation Filter
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        "Alokasi Pair yang Diizinkan Trading Otomatis:",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "Pilih pair mata uang / komoditas yang boleh dieksekusi oleh bot:",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(vertical = 4.dp)
                    ) {
                        items(pairs) { pair ->
                            val isAllowed = config.selectedPairs.contains(pair.symbol)
                            val isGold = pair.symbol.contains("XAU", ignoreCase = true)

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        if (isAllowed) {
                                            if (isGold) GoldAccent else CyanAccent
                                        } else DarkSurfaceElevated
                                    )
                                    .border(
                                        1.dp,
                                        if (isAllowed) (if (isGold) GoldAccent else CyanAccent) else BorderSubtle,
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable {
                                        val updatedList = if (isAllowed) {
                                            if (config.selectedPairs.size > 1) config.selectedPairs - pair.symbol else config.selectedPairs
                                        } else {
                                            config.selectedPairs + pair.symbol
                                        }
                                        onUpdateConfig(config.copy(selectedPairs = updatedList))
                                    }
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    if (isAllowed) {
                                        Icon(
                                            Icons.Default.Check,
                                            contentDescription = null,
                                            tint = Color.Black,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                    Text(
                                        pair.symbol,
                                        color = if (isAllowed) Color.Black else TextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 8. Candle Confirmation Signal Notification Settings
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyanAccent.copy(alpha = 0.3f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(CyanAccent.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("🔔", fontSize = 16.sp)
                            }
                            Column {
                                Text(
                                    "Notifikasi Sinyal & Konfirmasi Candle",
                                    color = TextPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    "Push notifikasi real-time saat candle konfirmasi terbentuk",
                                    color = TextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    // Toggle: Enable Notifications
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Aktifkan Notifikasi Sinyal", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text("Kirim notifikasi sistem & alert banner", color = TextSecondary, fontSize = 10.sp)
                        }
                        Switch(
                            checked = config.isSignalNotificationEnabled,
                            onCheckedChange = { onUpdateConfig(config.copy(isSignalNotificationEnabled = it)) },
                            colors = SwitchDefaults.colors(checkedTrackColor = CyanAccent)
                        )
                    }

                    // Toggle: Only Notify on Candle Confirmation
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("Filter: Wajib Konfirmasi Candle", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(BullishCandle.copy(alpha = 0.18f))
                                        .padding(horizontal = 4.dp, vertical = 1.dp)
                                ) {
                                    Text("Rekomendasi", color = BullishCandle, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Text("Hanya kirim notifikasi saat ada candle konfirmasi (Engulfing, Morning Star, Pinbar)", color = TextSecondary, fontSize = 10.sp)
                        }
                        Switch(
                            checked = config.notifyOnlyOnCandleConfirmation,
                            onCheckedChange = { onUpdateConfig(config.copy(notifyOnlyOnCandleConfirmation = it)) },
                            colors = SwitchDefaults.colors(checkedTrackColor = CyanAccent)
                        )
                    }

                    // Notification Sound & Vibration
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(DarkSurfaceElevated)
                                .clickable {
                                    onUpdateConfig(config.copy(enableNotificationSound = !config.enableNotificationSound))
                                }
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("🔊 Suara Notif", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                            Switch(
                                checked = config.enableNotificationSound,
                                onCheckedChange = { onUpdateConfig(config.copy(enableNotificationSound = it)) },
                                modifier = Modifier.size(36.dp, 20.dp),
                                colors = SwitchDefaults.colors(checkedTrackColor = CyanAccent)
                            )
                        }

                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(DarkSurfaceElevated)
                                .clickable {
                                    onUpdateConfig(config.copy(enableNotificationVibration = !config.enableNotificationVibration))
                                }
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("📳 Getar HP", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                            Switch(
                                checked = config.enableNotificationVibration,
                                onCheckedChange = { onUpdateConfig(config.copy(enableNotificationVibration = it)) },
                                modifier = Modifier.size(36.dp, 20.dp),
                                colors = SwitchDefaults.colors(checkedTrackColor = CyanAccent)
                            )
                        }
                    }

                    // Notification Minimum Confidence Threshold Slider
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Ambang Keyakinan Minimal Notifikasi", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text("≥ ${config.minNotificationConfidence}%", color = CyanAccent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = config.minNotificationConfidence.toFloat(),
                            onValueChange = { onUpdateConfig(config.copy(minNotificationConfidence = it.toInt())) },
                            valueRange = 60f..95f,
                            steps = 7,
                            colors = SliderDefaults.colors(thumbColor = CyanAccent, activeTrackColor = CyanAccent)
                        )
                    }

                    // Test Notification Action Button
                    Button(
                        onClick = onTestNotification,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyanAccent.copy(alpha = 0.15f),
                            contentColor = CyanAccent
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CyanAccent.copy(alpha = 0.5f))
                    ) {
                        Text("🔔 Tes Notifikasi Sinyal Konfirmasi Sekarang", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // 9. Restore Defaults Button
        item {
            OutlinedButton(
                onClick = {
                    onUpdateConfig(
                        BotStrategyConfig(
                            strategyType = config.strategyType,
                            isAutoTradingEnabled = config.isAutoTradingEnabled
                        )
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle)
            ) {
                Icon(Icons.Default.RestartAlt, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Kembalikan ke Parameter Standar Rekomendasi", color = TextSecondary, fontSize = 12.sp)
            }
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
fun BacktestTab(
    pairs: List<com.example.data.model.ForexPair>,
    selectedPair: com.example.data.model.ForexPair,
    backtestResult: BacktestResult?,
    onRunBacktest: (com.example.data.model.ForexPair, StrategyType, Double) -> Unit
) {
    var chosenPair by remember { mutableStateOf(selectedPair) }
    var chosenStrategy by remember { mutableStateOf(StrategyType.TREND_MOMENTUM) }
    var chosenLot by remember { mutableStateOf(0.10) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        "Simulator Backtesting Algoritma AI",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "Uji kinerja strategi trading bot pada data candlestick historis untuk mengetahui Win Rate, Profit Factor, dan Maximum Drawdown.",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )

                    // Run Backtest Action Button
                    Button(
                        onClick = { onRunBacktest(chosenPair, chosenStrategy, chosenLot) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("run_backtest_button"),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = Color.Black)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Jalankan Backtest (${chosenPair.symbol})", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Backtest Results Display (if available)
        backtestResult?.let { res ->
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            "Hasil Backtest: ${res.strategyName} (${res.pairSymbol})",
                            color = TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )

                        // Stats 2x2 Grid
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("Win Rate", color = TextSecondary, fontSize = 11.sp)
                                Text(
                                    "${String.format("%.1f", res.winRate)}%",
                                    color = if (res.winRate >= 60) BullishCandle else GoldAccent,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Total Profit / Loss", color = TextSecondary, fontSize = 11.sp)
                                Text(
                                    String.format("%+.2f USD", res.totalProfitLoss),
                                    color = if (res.totalProfitLoss >= 0) BullishCandle else BearishCandle,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("Profit Factor", color = TextSecondary, fontSize = 11.sp)
                                Text(
                                    String.format("%.2f", res.profitFactor),
                                    color = CyanAccent,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Total Trades", color = TextSecondary, fontSize = 11.sp)
                                Text(
                                    "${res.totalTrades} (${res.winningTrades}W / ${res.losingTrades}L)",
                                    color = TextPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Max Drawdown", color = TextSecondary, fontSize = 11.sp)
                                Text(
                                    "${String.format("%.1f", res.maxDrawdownPercent)}%",
                                    color = BearishCandle,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            items(res.tradeLogs.take(10)) { trade ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                "#${trade.index} ${trade.type} @ ${String.format("%.4f", trade.entryPrice)} -> ${String.format("%.4f", trade.exitPrice)}",
                                color = TextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(trade.reason, color = TextSecondary, fontSize = 10.sp)
                        }
                        Text(
                            String.format("%+.2f USD (%+.1f pips)", trade.profitLoss, trade.pips),
                            color = if (trade.profitLoss > 0) BullishCandle else BearishCandle,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BotLogsTab(logs: List<BotLogEntity>) {
    val dateFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (logs.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Belum ada log aktivitas bot.", color = TextSecondary)
                }
            }
        }

        items(logs) { log ->
            val levelColor = when (log.level) {
                "EXECUTION" -> BullishCandle
                "RISK" -> BearishCandle
                "SIGNAL" -> CyanAccent
                else -> TextSecondary
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        dateFormat.format(Date(log.timestamp)),
                        color = TextSecondary,
                        fontSize = 11.sp
                    )

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(levelColor.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            log.level,
                            color = levelColor,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        log.message,
                        color = TextPrimary,
                        fontSize = 11.sp,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
fun Mt5IntegrationTab(
    pairs: List<ForexPair>,
    selectedPair: ForexPair
) {
    val clipboardManager = LocalClipboardManager.current
    val coroutineScope = rememberCoroutineScope()

    var activeSymbol by remember { mutableStateOf("XAU/USD") }
    var selectedStrategy by remember { mutableStateOf(StrategyType.TREND_MOMENTUM) }
    var lotSize by remember { mutableDoubleStateOf(0.01) }
    var stopLossPips by remember { mutableDoubleStateOf(40.0) }
    var takeProfitPips by remember { mutableDoubleStateOf(80.0) }
    var useTrailing by remember { mutableStateOf(true) }
    var trailingPips by remember { mutableDoubleStateOf(25.0) }
    var magicNumber by remember { mutableLongStateOf(888123L) }

    var isCodeCopied by remember { mutableStateOf(false) }

    val currentMt5Config = remember(activeSymbol, selectedStrategy, lotSize, stopLossPips, takeProfitPips, useTrailing, trailingPips, magicNumber) {
        Mt5Config(
            symbol = activeSymbol,
            lotSize = lotSize,
            stopLossPips = stopLossPips,
            takeProfitPips = takeProfitPips,
            useTrailingStop = useTrailing,
            trailingPips = trailingPips,
            magicNumber = magicNumber,
            strategyType = selectedStrategy
        )
    }

    val generatedMql5Code = remember(currentMt5Config) {
        Mql5Generator.generateMql5Code(currentMt5Config)
    }

    val isGold = activeSymbol.contains("XAU", ignoreCase = true)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Hero Header Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (isGold) GoldAccent.copy(alpha = 0.5f) else CyanAccent.copy(alpha = 0.5f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isGold) GoldAccent else CyanAccent),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Code,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Column {
                                Text(
                                    "MetaTrader 5 (MT5) Bridge & EA",
                                    color = TextPrimary,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    "Ekspor Expert Advisor MQL5 & Auto Trading",
                                    color = TextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isGold) GoldAccent.copy(alpha = 0.2f) else CyanAccent.copy(alpha = 0.2f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                if (isGold) "GOLD READY" else "MT5 READY",
                                color = if (isGold) GoldAccent else CyanAccent,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Text(
                        text = "Aplikasi Kembangan Bot ini dapat digunakan langsung di MetaTrader 5 (MT5) untuk pair XAU/USD (Gold) maupun Forex. Anda dapat menyalin kode Expert Advisor (.mq5) yang dihasilkan di bawah ini dan menjalankannya di MT5 Desktop.",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                }
            }
        }

        // Pair Selection Chips (XAU/USD prioritized)
        item {
            Text(
                "Pilih Pair Target MT5:",
                color = TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 4.dp)
            ) {
                // Pin XAU/USD at front
                item {
                    val selected = activeSymbol == "XAU/USD"
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (selected) GoldAccent else DarkSurfaceElevated)
                            .border(1.dp, if (selected) GoldAccent else BorderSubtle, RoundedCornerShape(8.dp))
                            .clickable {
                                activeSymbol = "XAU/USD"
                                stopLossPips = 40.0
                                takeProfitPips = 80.0
                                trailingPips = 25.0
                            }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🥇 ", fontSize = 12.sp)
                            Text(
                                "XAU/USD (Gold)",
                                color = if (selected) Color.Black else TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                items(pairs.filter { it.symbol != "XAU/USD" }) { pair ->
                    val selected = activeSymbol == pair.symbol
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (selected) CyanAccent else DarkSurfaceElevated)
                            .border(1.dp, if (selected) CyanAccent else BorderSubtle, RoundedCornerShape(8.dp))
                            .clickable {
                                activeSymbol = pair.symbol
                                stopLossPips = 25.0
                                takeProfitPips = 50.0
                                trailingPips = 15.0
                            }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(
                            pair.symbol,
                            color = if (selected) Color.Black else TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Strategy Selector
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        "Strategi Logika EA",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )

                    StrategyType.entries.forEach { type ->
                        val isSelected = selectedStrategy == type
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) DarkSurfaceElevated else Color.Transparent)
                                .clickable { selectedStrategy = type }
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(16.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (isSelected) CyanAccent else BorderSubtle)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    type.title,
                                    color = if (isSelected) CyanAccent else TextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    "Kategori: ${type.badge}",
                                    color = TextSecondary,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // EA Parameter Inputs
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        "Parameter & Manajemen Risiko MT5",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )

                    // Lot Size
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Ukuran Lot", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text("Rekomendasi 0.01 untuk akun mikro/emas", color = TextSecondary, fontSize = 10.sp)
                        }
                        Text(String.format("%.2f Lot", lotSize), color = CyanAccent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Slider(
                        value = lotSize.toFloat(),
                        onValueChange = { lotSize = (Math.round(it * 100.0) / 100.0) },
                        valueRange = 0.01f..0.50f,
                        steps = 48,
                        colors = SliderDefaults.colors(thumbColor = CyanAccent, activeTrackColor = CyanAccent)
                    )

                    // Stop Loss & Take Profit in Pips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Stop Loss: ${stopLossPips.toInt()} Pips", color = BearishCandle, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Slider(
                                value = stopLossPips.toFloat(),
                                onValueChange = { stopLossPips = it.toDouble() },
                                valueRange = 10f..150f,
                                colors = SliderDefaults.colors(thumbColor = BearishCandle, activeTrackColor = BearishCandle)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Take Profit: ${takeProfitPips.toInt()} Pips", color = BullishCandle, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Slider(
                                value = takeProfitPips.toFloat(),
                                onValueChange = { takeProfitPips = it.toDouble() },
                                valueRange = 20f..300f,
                                colors = SliderDefaults.colors(thumbColor = BullishCandle, activeTrackColor = BullishCandle)
                            )
                        }
                    }

                    // Trailing Stop Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Trailing Stop Otomatis", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text("Kunci profit bertahap saat harga bergerak", color = TextSecondary, fontSize = 10.sp)
                        }
                        Switch(
                            checked = useTrailing,
                            onCheckedChange = { useTrailing = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CyanAccent,
                                checkedTrackColor = CyanAccent.copy(alpha = 0.4f)
                            )
                        )
                    }
                }
            }
        }

        // Generated MQL5 Code Viewer & Copy Button
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Code, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(18.dp))
                            Text("Kode MQL5 EA (MetaTrader 5)", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                clipboardManager.setText(AnnotatedString(generatedMql5Code))
                                isCodeCopied = true
                                coroutineScope.launch {
                                    delay(2500)
                                    isCodeCopied = false
                                }
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isCodeCopied) BullishCandle else CyanAccent,
                                contentColor = Color.Black
                            ),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = if (isCodeCopied) Icons.Default.CheckCircle else Icons.Default.ContentCopy,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                if (isCodeCopied) "Berhasil Disalin!" else "Salin Kode MQL5",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Code snippet preview box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF0D1117))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = generatedMql5Code.take(900) + "\n\n... (klik Salin Kode untuk kode lengkap 100% siap compile)",
                            color = Color(0xFF7EE787),
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            lineHeight = 14.sp
                        )
                    }
                }
            }
        }

        // Step-by-Step MT5 Installation Guide
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Default.HelpOutline, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(18.dp))
                        Text("Cara Pasang EA di MetaTrader 5 (MT5):", color = GoldAccent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }

                    Text("1. Buka aplikasi **MetaTrader 5** di PC/Laptop Anda.", color = TextPrimary, fontSize = 11.sp)
                    Text("2. Tekan tombol **F4** pada keyboard untuk membuka jendela **MetaEditor**.", color = TextPrimary, fontSize = 11.sp)
                    Text("3. Klik menu **File -> New -> Expert Advisor (template)**, beri nama `KembanganBot_${activeSymbol.replace("/", "")}`.", color = TextPrimary, fontSize = 11.sp)
                    Text("4. Hapus isi file default, lalu **Paste** kode yang telah disalin dari aplikasi ini.", color = TextPrimary, fontSize = 11.sp)
                    Text("5. Tekan tombol **Compile (F7)** dan pastikan status `0 errors, 0 warnings`.", color = TextPrimary, fontSize = 11.sp)
                    Text("6. Kembali ke MT5, buka chart **${activeSymbol}** (Timeframe M15 atau H1), lalu seret EA dari panel Navigator ke chart.", color = TextPrimary, fontSize = 11.sp)
                    Text("7. Pastikan tombol **'Algo Trading'** di toolbar MT5 dalam posisi aktif (Hijau).", color = TextPrimary, fontSize = 11.sp)
                }
            }
        }

        // Gold Trading Pro Tips
        if (isGold) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldAccent.copy(alpha = 0.3f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Shield, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(18.dp))
                            Text("Tips Khusus Trading XAU/USD (Emas) di MT5:", color = GoldAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Text("• **Volatilitas Tinggi**: Emas bergerak $20 - $40 per hari. Selalu gunakan Stop Loss wajib.", color = TextSecondary, fontSize = 11.sp)
                        Text("• **Kalkulasi Lot**: 0.01 lot XAUUSD setara 1 troy oz (setiap gerak $1.00 = profit/loss $1.00).", color = TextSecondary, fontSize = 11.sp)
                        Text("• **Jam Terbaik**: Sesi overlap London & New York (19.00 - 23.00 WIB) memiliki likuiditas paling tinggi.", color = TextSecondary, fontSize = 11.sp)
                        Text("• **Waspada Berita**: Non-Farm Payroll (NFP), US CPI, dan FOMC dapat menyebabkan lonjakan spread pada broker.", color = TextSecondary, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

