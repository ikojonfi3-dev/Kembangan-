package com.example.data.model

data class CandleStick(
    val timestamp: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double,
    val ema20: Double? = null,
    val ema50: Double? = null,
    val rsi: Double? = null,
    val upperBollinger: Double? = null,
    val lowerBollinger: Double? = null,
    val middleBollinger: Double? = null,
    val macd: Double? = null,
    val macdSignal: Double? = null,
    val macdHist: Double? = null
) {
    val isBullish: Boolean get() = close >= open
    val bodyHeight: Double get() = kotlin.math.abs(close - open)
    val upperWick: Double get() = high - kotlin.math.max(open, close)
    val lowerWick: Double get() = kotlin.math.min(open, close) - low
}

enum class TimeFrame(val label: String, val minutes: Int) {
    M1("1m", 1),
    M5("5m", 5),
    M15("15m", 15),
    H1("1h", 60),
    H4("4h", 240),
    D1("1D", 1440)
}
