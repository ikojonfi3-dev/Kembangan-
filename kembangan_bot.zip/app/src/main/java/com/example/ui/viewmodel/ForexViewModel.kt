package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.BotLogEntity
import com.example.data.local.OrderType
import com.example.data.local.TradePositionEntity
import com.example.data.model.AccountState
import com.example.data.model.BotStrategyConfig
import com.example.data.model.CandleStick
import com.example.data.model.EconomicEvent
import com.example.data.model.ForexPair
import com.example.data.model.MockEconomicCalendar
import com.example.data.model.PerformanceMetrics
import com.example.data.model.StrategyType
import com.example.data.model.TimeFrame
import com.example.data.model.TradeSignal
import com.example.data.remote.GeminiClient
import com.example.domain.engine.BacktestEngine
import com.example.domain.engine.BacktestResult
import com.example.domain.engine.BotEngine
import com.example.domain.engine.MarketSimulator
import com.example.domain.notification.SignalNotificationHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: String, // "user" or "bot"
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class AiScanResult(
    val pairSymbol: String,
    val analysisText: String,
    val isLoading: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

class ForexViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val tradeDao = db.tradeDao()
    private val botLogDao = db.botLogDao()

    val marketSimulator = MarketSimulator()
    val botEngine = BotEngine(tradeDao, botLogDao, marketSimulator, viewModelScope)

    // UI States
    val pairs: StateFlow<List<ForexPair>> = marketSimulator.pairs
    val selectedPair = MutableStateFlow<ForexPair>(marketSimulator.pairs.value.first())
    val selectedTimeFrame = MutableStateFlow(TimeFrame.H1)

    val strategyConfig: StateFlow<BotStrategyConfig> = botEngine.strategyConfig
    val accountState: StateFlow<AccountState> = botEngine.accountState
    val liveSignals: StateFlow<List<TradeSignal>> = botEngine.liveSignals
    val latestSignalAlert: StateFlow<TradeSignal?> = botEngine.latestSignalAlert
    val performanceMetrics: StateFlow<PerformanceMetrics> = botEngine.performanceMetrics

    val openPositions: StateFlow<List<TradePositionEntity>> = tradeDao.getOpenPositions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val closedPositions: StateFlow<List<TradePositionEntity>> = tradeDao.getClosedPositions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val botLogs: StateFlow<List<BotLogEntity>> = botLogDao.getRecentLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val economicEvents = MutableStateFlow<List<EconomicEvent>>(MockEconomicCalendar.events)

    // Active chart candles
    private val _currentCandles = MutableStateFlow<List<CandleStick>>(emptyList())
    val currentCandles: StateFlow<List<CandleStick>> = _currentCandles.asStateFlow()

    // Gemini AI Scan State
    private val _aiScanResult = MutableStateFlow<AiScanResult?>(null)
    val aiScanResult: StateFlow<AiScanResult?> = _aiScanResult.asStateFlow()

    // Backtest State
    private val _backtestResult = MutableStateFlow<BacktestResult?>(null)
    val backtestResult: StateFlow<BacktestResult?> = _backtestResult.asStateFlow()

    // Chatbot state
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                sender = "bot",
                text = "Halo! Saya ForexAI Bot Trader. Anda bisa menanyakan kondisi pasar saat ini, analisis pair forex tertentu, sinyal trading, strategi Smart Money Concepts (SMC), atau manajemen risiko."
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()
    val isChatLoading = MutableStateFlow(false)

    init {
        // Initialize Signal Notification Channel
        SignalNotificationHelper.createNotificationChannel(application)

        // Set callback to send system push notification when confirmed candle signal appears
        botEngine.onNewConfirmedSignalCallback = { signal ->
            val cfg = strategyConfig.value
            if (cfg.isSignalNotificationEnabled) {
                SignalNotificationHelper.sendSignalNotification(
                    context = getApplication(),
                    signal = signal,
                    enableSound = cfg.enableNotificationSound,
                    enableVibration = cfg.enableNotificationVibration
                )
            }
        }

        refreshCandles()

        // Start 1-second live market tick loop
        viewModelScope.launch(Dispatchers.Default) {
            while (isActive) {
                delay(1200)
                val updatedPairs = marketSimulator.tick()
                val currentSelectedSymbol = selectedPair.value.symbol
                updatedPairs.firstOrNull { it.symbol == currentSelectedSymbol }?.let {
                    selectedPair.value = it
                }
                refreshCandles()
                botEngine.processMarketTick(updatedPairs, openPositions.value)
            }
        }

        // Observer for closed trades to update metrics
        viewModelScope.launch {
            closedPositions.collect { list ->
                botEngine.updateMetrics(list)
            }
        }
    }

    fun dismissSignalAlert() {
        botEngine.dismissSignalAlert()
    }

    fun triggerTestSignalNotification(customPair: String? = null) {
        botEngine.triggerTestSignalNotification(customPair ?: selectedPair.value.symbol)
    }

    fun selectPair(pair: ForexPair) {
        selectedPair.value = pair
        refreshCandles()
    }

    fun selectTimeFrame(timeFrame: TimeFrame) {
        selectedTimeFrame.value = timeFrame
        refreshCandles()
    }

    private fun refreshCandles() {
        _currentCandles.value = marketSimulator.getCandles(
            selectedPair.value.symbol,
            selectedTimeFrame.value
        )
    }

    fun toggleAutoTrading(enabled: Boolean) {
        botEngine.toggleAutoTrading(enabled)
    }

    fun updateStrategyConfig(config: BotStrategyConfig) {
        botEngine.updateConfig(config)
    }

    fun placeOrder(orderType: OrderType, lotSize: Double, slPips: Double, tpPips: Double) {
        viewModelScope.launch(Dispatchers.IO) {
            val pair = selectedPair.value
            val entryPrice = if (orderType == OrderType.BUY) pair.currentAsk else pair.currentBid
            val pipDist = 1.0 / pair.pipMultiplier
            val sl = if (slPips > 0) {
                if (orderType == OrderType.BUY) entryPrice - (slPips * pipDist) else entryPrice + (slPips * pipDist)
            } else 0.0
            val tp = if (tpPips > 0) {
                if (orderType == OrderType.BUY) entryPrice + (tpPips * pipDist) else entryPrice - (tpPips * pipDist)
            } else 0.0

            botEngine.executeManualTrade(
                pair = pair,
                orderType = orderType,
                lotSize = lotSize,
                stopLoss = sl,
                takeProfit = tp,
                strategyTag = "MANUAL"
            )
        }
    }

    fun executeSignalDirectly(signal: TradeSignal) {
        viewModelScope.launch(Dispatchers.IO) {
            val pair = pairs.value.firstOrNull { it.symbol == signal.pairSymbol } ?: selectedPair.value
            val orderType = if (signal.type == com.example.data.model.SignalType.BUY) OrderType.BUY else OrderType.SELL
            botEngine.executeManualTrade(
                pair = pair,
                orderType = orderType,
                lotSize = strategyConfig.value.lotSize,
                stopLoss = signal.stopLoss,
                takeProfit = signal.takeProfit1,
                strategyTag = signal.strategyName
            )
        }
    }

    fun closePosition(positionId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            botEngine.closePositionManually(positionId)
        }
    }

    fun resetDemoBalance() {
        viewModelScope.launch(Dispatchers.IO) {
            botEngine.resetDemoBalance()
        }
    }

    fun scanWithGeminiAI(pair: ForexPair = selectedPair.value) {
        _aiScanResult.value = AiScanResult(pairSymbol = pair.symbol, analysisText = "", isLoading = true)
        viewModelScope.launch(Dispatchers.IO) {
            val candles = marketSimulator.getCandles(pair.symbol, TimeFrame.H1)
            val last = candles.lastOrNull()
            val rsi = last?.rsi ?: 50.0
            val ema20 = last?.ema20 ?: pair.currentBid
            val ema50 = last?.ema50 ?: pair.currentBid

            val prompt = """
                Analisis pasar Forex untuk pasangan mata uang: ${pair.symbol} (${pair.name})
                Harga Bid Saat Ini: ${pair.formattedPrice}, Ask: ${pair.formattedAsk}, Spread: ${String.format("%.1f", pair.spread)} pips.
                24h High: ${pair.high24h}, 24h Low: ${pair.low24h}, Change: ${pair.formattedChange}.
                Indikator Teknis (H1):
                - RSI(14): ${String.format("%.1f", rsi)}
                - EMA 20: ${String.format("%.${pair.decimals}f", ema20)}
                - EMA 50: ${String.format("%.${pair.decimals}f", ema50)}
                - Bollinger Bands: Upper ${String.format("%.${pair.decimals}f", last?.upperBollinger ?: 0.0)}, Lower ${String.format("%.${pair.decimals}f", last?.lowerBollinger ?: 0.0)}

                Berikan rekomendasi AI Trading Bot lengkap mencakup:
                1. Sinyal Aksi (BUY / SELL / WAIT)
                2. Confidence Level (%)
                3. Entry Zone, Stop Loss (SL), dan Take Profit 1 & 2 (TP1, TP2)
                4. Rasio Risk-to-Reward
                5. Analisis Fundamental & Price Action singkat.
            """.trimIndent()

            val aiResponse = GeminiClient.askGemini(prompt)
            _aiScanResult.value = AiScanResult(
                pairSymbol = pair.symbol,
                analysisText = aiResponse,
                isLoading = false
            )
        }
    }

    fun clearAiScan() {
        _aiScanResult.value = null
    }

    fun runBacktest(pair: ForexPair, strategy: StrategyType, lotSize: Double) {
        viewModelScope.launch(Dispatchers.Default) {
            val candles = marketSimulator.getCandles(pair.symbol, TimeFrame.H1)
            val result = BacktestEngine.runBacktest(pair, strategy, candles, lotSize)
            _backtestResult.value = result
        }
    }

    fun sendChatMessage(userText: String) {
        if (userText.isBlank()) return
        val userMsg = ChatMessage(sender = "user", text = userText)
        _chatMessages.value = _chatMessages.value + userMsg
        isChatLoading.value = true

        viewModelScope.launch(Dispatchers.IO) {
            val prompt = "User Pertanyaan Forex: $userText\n" +
                    "Konteks Pair Aktif: ${selectedPair.value.symbol} di harga ${selectedPair.value.formattedPrice}. " +
                    "Jawab sebagai AI Trading Bot expert, ringkas, akurat, edukatif dan praktis."
            val botReply = GeminiClient.askGemini(prompt)
            _chatMessages.value = _chatMessages.value + ChatMessage(sender = "bot", text = botReply)
            isChatLoading.value = false
        }
    }
}
