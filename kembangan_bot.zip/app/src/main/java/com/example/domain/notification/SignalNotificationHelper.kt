package com.example.domain.notification

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity
import com.example.data.model.SignalType
import com.example.data.model.TradeSignal

object SignalNotificationHelper {

    const val CHANNEL_ID = "kembangan_signals_channel"
    const val CHANNEL_NAME = "Sinyal & Konfirmasi Candle Kembangan Bot"
    private const val CHANNEL_DESC = "Notifikasi saat candle konfirmasi entry open posisi terdeteksi oleh AI"

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, importance).apply {
                description = CHANNEL_DESC
                enableLights(true)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 250, 150, 250)
            }
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            notificationManager?.createNotificationChannel(channel)
        }
    }

    fun sendSignalNotification(
        context: Context,
        signal: TradeSignal,
        enableSound: Boolean = true,
        enableVibration: Boolean = true
    ) {
        createNotificationChannel(context)

        // Permission check for Android 13+ (TIRAMISU)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ActivityCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                return
            }
        }

        val isBuy = signal.type == SignalType.BUY
        val actionText = if (isBuy) "🟢 ENTRY BUY" else "🔴 ENTRY SELL"
        val title = "$actionText: ${signal.pairSymbol} @ ${signal.formattedEntry}"

        val contentText = "🕯️ Konfirmasi: ${signal.confirmationCandle} (${signal.candlePatternQuality}) | TP: ${signal.formattedTP1} | SL: ${signal.formattedSL}"

        val bigText = buildString {
            append("🕯️ Konfirmasi Candle: ${signal.confirmationCandle} (${signal.candlePatternQuality})\n")
            append("🎯 Target Profit 1: ${signal.formattedTP1} (TP2: ${signal.formattedTP2})\n")
            append("🛑 Stop Loss: ${signal.formattedSL} (Risk:Reward ${signal.riskRewardRatio})\n")
            append("⭐ Keyakinan AI: ${signal.confidenceScore}% | Strategi: ${signal.strategyName}\n")
            append("💡 Analisis: ${signal.reasoning}")
        }

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("EXTRA_NAV_TARGET", "signals")
            putExtra("EXTRA_SIGNAL_PAIR", signal.pairSymbol)
        }

        val pendingIntentFlags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            signal.pairSymbol.hashCode(),
            intent,
            pendingIntentFlags
        )

        val soundUri = if (enableSound) RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION) else null

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_notify_more)
            .setContentTitle(title)
            .setContentText(contentText)
            .setStyle(NotificationCompat.BigTextStyle().bigText(bigText))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        if (soundUri != null) {
            builder.setSound(soundUri)
        }

        if (enableVibration) {
            builder.setVibrate(longArrayOf(0, 300, 150, 300))
        }

        val notificationId = (signal.pairSymbol.hashCode() and 0x7FFFFFFF)
        try {
            NotificationManagerCompat.from(context).notify(notificationId, builder.build())
        } catch (_: SecurityException) {
            // Handled if permissions not yet granted
        }
    }
}
