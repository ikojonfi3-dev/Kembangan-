package com.example.domain.engine

import com.example.data.model.ForexPair
import com.example.data.model.StrategyType
import com.example.data.model.TradeSignal

data class Mt5Config(
    val symbol: String = "XAU/USD",
    val lotSize: Double = 0.01,
    val stopLossPips: Double = 40.0,
    val takeProfitPips: Double = 80.0,
    val useTrailingStop: Boolean = true,
    val trailingPips: Double = 25.0,
    val magicNumber: Long = 888123,
    val strategyType: StrategyType = StrategyType.TREND_MOMENTUM,
    val webhookUrl: String = "https://api.forexai.app/v1/mt5-bridge"
)

object Mql5Generator {

    fun generateMql5Code(config: Mt5Config): String {
        val cleanSymbol = config.symbol.replace("/", "")
        val isGold = config.symbol.contains("XAU", ignoreCase = true)

        return """
//+------------------------------------------------------------------+
//|                                 KembanganBot_${cleanSymbol}_EA.mq5 |
//|                               Copyright 2026, Kembangan Bot AI   |
//|                                             https://ai.studio/   |
//+------------------------------------------------------------------+
#property copyright "Kembangan Bot AI"
#property link      "https://ai.studio/"
#property version   "2.00"
#property description "Kembangan Bot Automated EA for ${config.symbol} (Strategy: ${config.strategyType.title})"

#include <Trade\Trade.mqh>
CTrade trade;

//--- Input Parameters
input group "=== Risk & Lot Management ==="
input double   InpLotSize         = ${config.lotSize};    // Lot Size (e.g. 0.01 for XAUUSD Micro)
input double   InpStopLossPips    = ${config.stopLossPips};   // Stop Loss (in Pips)
input double   InpTakeProfitPips  = ${config.takeProfitPips};   // Take Profit (in Pips)
input bool     InpUseTrailing     = ${if (config.useTrailingStop) "true" else "false"};    // Enable Trailing Stop
input double   InpTrailingPips    = ${config.trailingPips};   // Trailing Distance (in Pips)
input ulong    InpMagicNumber     = ${config.magicNumber};  // Magic Number ID

input group "=== Indicator Settings ==="
input int      InpEmaFastPeriod   = 20;        // Fast EMA Period
input int      InpEmaSlowPeriod   = 50;        // Slow EMA Period
input int      InpRsiPeriod       = 14;        // RSI Period
input double   InpRsiOverbought   = 70.0;      // RSI Overbought Level
input double   InpRsiOversold     = 30.0;      // RSI Oversold Level

//--- Global Variables
int handleEmaFast = INVALID_HANDLE;
int handleEmaSlow = INVALID_HANDLE;
int handleRsi     = INVALID_HANDLE;
datetime lastBarTime = 0;

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
{
    trade.SetExpertMagicNumber(InpMagicNumber);
    trade.SetDeviationInPoints(20);
    trade.SetTypeFilling(ORDER_FILLING_IOC);

    // Create Indicator Handles
    handleEmaFast = iMA(_Symbol, _Period, InpEmaFastPeriod, 0, MODE_EMA, PRICE_CLOSE);
    handleEmaSlow = iMA(_Symbol, _Period, InpEmaSlowPeriod, 0, MODE_EMA, PRICE_CLOSE);
    handleRsi     = iRSI(_Symbol, _Period, InpRsiPeriod, PRICE_CLOSE);

    if(handleEmaFast == INVALID_HANDLE || handleEmaSlow == INVALID_HANDLE || handleRsi == INVALID_HANDLE)
    {
        Print("Failed to create indicator handles for ForexAI EA!");
        return(INIT_FAILED);
    }

    Print("ForexAI EA Initialized for ", _Symbol, " | Magic: ", InpMagicNumber);
    return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
    IndicatorRelease(handleEmaFast);
    IndicatorRelease(handleEmaSlow);
    IndicatorRelease(handleRsi);
}

//+------------------------------------------------------------------+
//| Helper: Pip to Points Multiplier                                 |
//+------------------------------------------------------------------+
double GetPipMultiplier()
{
    ${if (isGold) "// Gold/XAUUSD pip is usually 0.10 or 10 points\n    return (_Digits == 2 || _Digits == 3) ? 10.0 : 1.0;" else "// Standard Forex pip multiplier\n    return (_Digits == 3 || _Digits == 5) ? 10.0 : 1.0;"}
}

//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
{
    // Trailing Stop Logic
    if(InpUseTrailing)
    {
        ApplyTrailingStop();
    }

    // Process only on new bar open
    datetime currentBarTime = iTime(_Symbol, _Period, 0);
    if(currentBarTime == lastBarTime) return;
    lastBarTime = currentBarTime;

    // Read indicator buffers
    double emaFast[], emaSlow[], rsi[];
    ArraySetAsSeries(emaFast, true);
    ArraySetAsSeries(emaSlow, true);
    ArraySetAsSeries(rsi, true);

    if(CopyBuffer(handleEmaFast, 0, 1, 2, emaFast) < 2) return;
    if(CopyBuffer(handleEmaSlow, 0, 1, 2, emaSlow) < 2) return;
    if(CopyBuffer(handleRsi, 0, 1, 2, rsi) < 2) return;

    bool isBuySignal = false;
    bool isSellSignal = false;

    // ForexAI Strategy Engine
    if(emaFast[0] > emaSlow[0] && emaFast[1] <= emaSlow[1] && rsi[0] > 50.0 && rsi[0] < InpRsiOverbought)
    {
        isBuySignal = true;
    }
    else if(emaFast[0] < emaSlow[0] && emaFast[1] >= emaSlow[1] && rsi[0] < 50.0 && rsi[0] > InpRsiOversold)
    {
        isSellSignal = true;
    }

    // Check Open Positions
    int totalPositions = PositionsTotal();
    bool hasOpenPos = false;
    for(int i = 0; i < totalPositions; i++)
    {
        if(PositionGetSymbol(i) == _Symbol && PositionGetInteger(POSITION_MAGIC) == InpMagicNumber)
        {
            hasOpenPos = true;
            break;
        }
    }

    double pipMultiplier = GetPipMultiplier();
    double point = _Point;

    // Execute Buy
    if(isBuySignal && !hasOpenPos)
    {
        double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
        double sl = ask - (InpStopLossPips * pipMultiplier * point);
        double tp = ask + (InpTakeProfitPips * pipMultiplier * point);
        
        trade.Buy(InpLotSize, _Symbol, ask, sl, tp, "ForexAI BUY ${cleanSymbol}");
        Print("ForexAI [BUY] Executed on ", _Symbol, " @ ", ask, " SL: ", sl, " TP: ", tp);
    }
    // Execute Sell
    else if(isSellSignal && !hasOpenPos)
    {
        double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
        double sl = bid + (InpStopLossPips * pipMultiplier * point);
        double tp = bid - (InpTakeProfitPips * pipMultiplier * point);
        
        trade.Sell(InpLotSize, _Symbol, bid, sl, tp, "ForexAI SELL ${cleanSymbol}");
        Print("ForexAI [SELL] Executed on ", _Symbol, " @ ", bid, " SL: ", sl, " TP: ", tp);
    }
}

//+------------------------------------------------------------------+
//| Trailing Stop Management                                         |
//+------------------------------------------------------------------+
void ApplyTrailingStop()
{
    double pipMultiplier = GetPipMultiplier();
    double point = _Point;
    double trailDistance = InpTrailingPips * pipMultiplier * point;

    for(int i = PositionsTotal() - 1; i >= 0; i--)
    {
        if(PositionGetSymbol(i) == _Symbol && PositionGetInteger(POSITION_MAGIC) == InpMagicNumber)
        {
            ulong ticket = PositionGetTicket(i);
            long posType = PositionGetInteger(POSITION_TYPE);
            double currentSL = PositionGetDouble(POSITION_SL);
            double currentPrice = (posType == POSITION_TYPE_BUY) ? SymbolInfoDouble(_Symbol, SYMBOL_BID) : SymbolInfoDouble(_Symbol, SYMBOL_ASK);
            double openPrice = PositionGetDouble(POSITION_PRICE_OPEN);

            if(posType == POSITION_TYPE_BUY)
            {
                if(currentPrice - openPrice > trailDistance)
                {
                    double newSL = currentPrice - trailDistance;
                    if(newSL > currentSL + (5 * point))
                    {
                        trade.PositionModify(ticket, newSL, PositionGetDouble(POSITION_TP));
                    }
                }
            }
            else if(posType == POSITION_TYPE_SELL)
            {
                if(openPrice - currentPrice > trailDistance)
                {
                    double newSL = currentPrice + trailDistance;
                    if(newSL < currentSL - (5 * point) || currentSL == 0.0)
                    {
                        trade.PositionModify(ticket, newSL, PositionGetDouble(POSITION_TP));
                    }
                }
            }
        }
    }
}
//+------------------------------------------------------------------+
""".trimIndent()
    }

    fun formatSignalForMt5(signal: TradeSignal): String {
        val cleanSymbol = signal.pairSymbol.replace("/", "")
        val typeStr = signal.type.name
        return """
📢 FOREXAI MT5 SIGNAL ALERT
Pair: $cleanSymbol (XAUUSD / Gold)
Action: $typeStr
Entry: ${signal.entryPrice}
Stop Loss: ${signal.stopLoss}
Take Profit 1: ${signal.takeProfit1}
Take Profit 2: ${signal.takeProfit2}
Risk/Reward: ${signal.riskRewardRatio}
Confidence: ${signal.confidenceScore}%
Strategy: ${signal.strategyName}
        """.trimIndent()
    }
}
