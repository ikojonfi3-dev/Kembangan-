package com.example.domain.engine

import com.example.data.model.CandleStick
import com.example.data.model.SignalType
import com.example.data.model.StrategyType
import com.example.data.model.TradeSignal
import java.util.UUID
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

object TechnicalAnalysis {

    fun calculateEma(candles: List<CandleStick>, period: Int): List<Double?> {
        if (candles.size < period) return List(candles.size) { null }
        val multiplier = 2.0 / (period + 1)
        val result = ArrayList<Double?>()

        // First EMA is simple average
        var sma = 0.0
        for (i in 0 until period) {
            sma += candles[i].close
            result.add(null)
        }
        sma /= period
        result[period - 1] = sma

        var prevEma = sma
        for (i in period until candles.size) {
            val currentClose = candles[i].close
            val currentEma = (currentClose - prevEma) * multiplier + prevEma
            result.add(currentEma)
            prevEma = currentEma
        }
        return result
    }

    fun calculateRsi(candles: List<CandleStick>, period: Int = 14): List<Double?> {
        if (candles.size <= period) return List(candles.size) { null }
        val result = ArrayList<Double?>()
        for (i in 0 until period) {
            result.add(null)
        }

        var gainSum = 0.0
        var lossSum = 0.0
        for (i in 1..period) {
            val diff = candles[i].close - candles[i - 1].close
            if (diff >= 0) gainSum += diff else lossSum += -diff
        }

        var avgGain = gainSum / period
        var avgLoss = lossSum / period
        var rs = if (avgLoss == 0.0) 100.0 else avgGain / avgLoss
        var rsi = 100.0 - (100.0 / (1.0 + rs))
        result.add(rsi)

        for (i in (period + 1) until candles.size) {
            val diff = candles[i].close - candles[i - 1].close
            val gain = if (diff > 0) diff else 0.0
            val loss = if (diff < 0) -diff else 0.0

            avgGain = (avgGain * (period - 1) + gain) / period
            avgLoss = (avgLoss * (period - 1) + loss) / period

            rs = if (avgLoss == 0.0) 100.0 else avgGain / avgLoss
            rsi = 100.0 - (100.0 / (1.0 + rs))
            result.add(rsi)
        }
        return result
    }

    fun calculateBollingerBands(
        candles: List<CandleStick>,
        period: Int = 20,
        k: Double = 2.0
    ): Triple<List<Double?>, List<Double?>, List<Double?>> {
        val upper = ArrayList<Double?>()
        val middle = ArrayList<Double?>()
        val lower = ArrayList<Double?>()

        for (i in candles.indices) {
            if (i < period - 1) {
                upper.add(null)
                middle.add(null)
                lower.add(null)
                continue
            }
            val slice = candles.subList(i - period + 1, i + 1)
            val mean = slice.map { it.close }.average()
            val variance = slice.map { (it.close - mean).pow(2) }.average()
            val stdDev = sqrt(variance)

            middle.add(mean)
            upper.add(mean + (k * stdDev))
            lower.add(mean - (k * stdDev))
        }
        return Triple(upper, middle, lower)
    }

    fun calculateAtr(candles: List<CandleStick>, period: Int = 14): Double {
        if (candles.size < 2) return 0.0010
        val trs = ArrayList<Double>()
        for (i in 1 until candles.size) {
            val h = candles[i].high
            val l = candles[i].low
            val prevC = candles[i - 1].close
            val tr = max(h - l, max(kotlin.math.abs(h - prevC), kotlin.math.abs(l - prevC)))
            trs.add(tr)
        }
        val subTrs = trs.takeLast(period)
        return if (subTrs.isNotEmpty()) subTrs.average() else 0.0010
    }

    fun enrichCandlesWithIndicators(candles: List<CandleStick>): List<CandleStick> {
        val ema20List = calculateEma(candles, 20)
        val ema50List = calculateEma(candles, 50)
        val rsiList = calculateRsi(candles, 14)
        val (upperBB, middleBB, lowerBB) = calculateBollingerBands(candles, 20, 2.0)

        return candles.mapIndexed { index, candle ->
            candle.copy(
                ema20 = ema20List.getOrNull(index),
                ema50 = ema50List.getOrNull(index),
                rsi = rsiList.getOrNull(index),
                upperBollinger = upperBB.getOrNull(index),
                middleBollinger = middleBB.getOrNull(index),
                lowerBollinger = lowerBB.getOrNull(index)
            )
        }
    }

    data class CandleConfirmationInfo(
        val patternName: String,
        val isConfirmed: Boolean,
        val quality: String,
        val description: String
    )

    fun detectConfirmationCandle(
        candles: List<CandleStick>,
        signalType: SignalType,
        atr: Double
    ): CandleConfirmationInfo {
        if (candles.size < 3) {
            return CandleConfirmationInfo("Standar Candle", false, "Netral", "Belum cukup data konfirmasi.")
        }
        val last = candles.last()
        val prev = candles[candles.size - 2]
        val prev2 = candles[candles.size - 3]

        if (signalType == SignalType.BUY) {
            // 1. Morning Star (3 candle pattern)
            if (!prev2.isBullish && prev2.bodyHeight > atr * 0.4 &&
                prev.bodyHeight < atr * 0.3 &&
                last.isBullish && last.close > (prev2.open + prev2.close) / 2
            ) {
                return CandleConfirmationInfo(
                    "Morning Star Reversal",
                    true,
                    "Konfirmasi A+",
                    "Formasi 3 candle pembalikan arah bullish valid di area support."
                )
            }

            // 2. Bullish Engulfing
            if (!prev.isBullish && last.isBullish &&
                last.close >= prev.open && last.open <= prev.close &&
                last.bodyHeight >= prev.bodyHeight * 0.9
            ) {
                return CandleConfirmationInfo(
                    "Bullish Engulfing",
                    true,
                    "Konfirmasi A+",
                    "Candle hijau menelan penuh candle merah sebelumnya dengan tekanan beli kuat."
                )
            }

            // 3. Hammer / Long Lower Wick Rejection
            if (last.lowerWick >= last.bodyHeight * 1.5 && last.upperWick <= last.bodyHeight * 0.6) {
                return CandleConfirmationInfo(
                    "Hammer / Pinbar Rejection",
                    true,
                    "Konfirmasi A+",
                    "Rejection ekor bawah panjang mengindikasikan penolakan keras harga rendah oleh buyers."
                )
            }

            // 4. Bullish Marubozu Momentum
            if (last.isBullish && last.bodyHeight > atr * 0.7 && last.upperWick <= last.bodyHeight * 0.15) {
                return CandleConfirmationInfo(
                    "Bullish Marubozu Momentum",
                    true,
                    "Konfirmasi A",
                    "Candle impulsif bodi penuh menembus resisten tanpa perlawanan signifikan."
                )
            }

            // 5. Piercing Line
            if (!prev.isBullish && last.isBullish &&
                last.open < prev.close && last.close >= (prev.open + prev.close) / 2
            ) {
                return CandleConfirmationInfo(
                    "Piercing Line Reversal",
                    true,
                    "Konfirmasi A",
                    "Penetrasi lebih dari 50% bodi candle merah sebelumnya."
                )
            }

            // Default Bullish confirmation
            if (last.isBullish && last.close > prev.high) {
                return CandleConfirmationInfo(
                    "Breakout High Candle",
                    true,
                    "Konfirmasi A",
                    "Penutupan candle di atas level tertinggi candle sebelumnya."
                )
            }

            return CandleConfirmationInfo(
                "Bullish Pullback",
                last.isBullish,
                "Valid B",
                "Pergerakan harga menunjukkan kecenderungan bullish."
            )
        } else if (signalType == SignalType.SELL) {
            // 1. Evening Star (3 candle pattern)
            if (prev2.isBullish && prev2.bodyHeight > atr * 0.4 &&
                prev.bodyHeight < atr * 0.3 &&
                !last.isBullish && last.close < (prev2.open + prev2.close) / 2
            ) {
                return CandleConfirmationInfo(
                    "Evening Star Reversal",
                    true,
                    "Konfirmasi A+",
                    "Formasi 3 candle pembalikan arah bearish valid di area resisten."
                )
            }

            // 2. Bearish Engulfing
            if (prev.isBullish && !last.isBullish &&
                last.close <= prev.open && last.open >= prev.close &&
                last.bodyHeight >= prev.bodyHeight * 0.9
            ) {
                return CandleConfirmationInfo(
                    "Bearish Engulfing",
                    true,
                    "Konfirmasi A+",
                    "Candle merah menelan penuh candle hijau sebelumnya dengan dominasi seller agresif."
                )
            }

            // 3. Shooting Star / Long Upper Wick Rejection
            if (last.upperWick >= last.bodyHeight * 1.5 && last.lowerWick <= last.bodyHeight * 0.6) {
                return CandleConfirmationInfo(
                    "Shooting Star / Pinbar Rejection",
                    true,
                    "Konfirmasi A+",
                    "Penolakan ekor atas panjang menunjukkan tekanan jual instansional di supply zone."
                )
            }

            // 4. Bearish Marubozu Momentum
            if (!last.isBullish && last.bodyHeight > atr * 0.7 && last.lowerWick <= last.bodyHeight * 0.15) {
                return CandleConfirmationInfo(
                    "Bearish Marubozu Breakdown",
                    true,
                    "Konfirmasi A",
                    "Candle merah solid panjang menembus support tanpa dorongan buyer."
                )
            }

            // 5. Dark Cloud Cover
            if (prev.isBullish && !last.isBullish &&
                last.open > prev.close && last.close <= (prev.open + prev.close) / 2
            ) {
                return CandleConfirmationInfo(
                    "Dark Cloud Cover",
                    true,
                    "Konfirmasi A",
                    "Penetrasi bearish menembus lebih dari separuh bodi candle bullish."
                )
            }

            // Default Bearish confirmation
            if (!last.isBullish && last.close < prev.low) {
                return CandleConfirmationInfo(
                    "Breakdown Low Candle",
                    true,
                    "Konfirmasi A",
                    "Penutupan candle di bawah level terendah candle sebelumnya."
                )
            }

            return CandleConfirmationInfo(
                "Bearish Pullback",
                !last.isBullish,
                "Valid B",
                "Pergerakan harga menunjukkan kecenderungan bearish."
            )
        }

        return CandleConfirmationInfo("Konsolidasi / Doji", false, "Netral", "Pasar bergerak mendatar tanpa konfirmasi arah.")
    }

    fun generateBotSignal(
        pairSymbol: String,
        candles: List<CandleStick>,
        strategy: StrategyType,
        pipMultiplier: Double = 10000.0,
        decimals: Int = 4
    ): TradeSignal {
        if (candles.size < 30) {
            return TradeSignal(
                id = UUID.randomUUID().toString(),
                pairSymbol = pairSymbol,
                type = SignalType.HOLD,
                strategyName = strategy.title,
                entryPrice = candles.lastOrNull()?.close ?: 1.0,
                stopLoss = 0.0,
                takeProfit1 = 0.0,
                takeProfit2 = 0.0,
                riskRewardRatio = "1:2",
                confidenceScore = 50,
                reasoning = "Insufficient candle history for algorithmic verification.",
                keyIndicators = "Calibrating indicators...",
                isAIGenerated = false,
                confirmationCandle = "Data Belum Lengkap",
                isCandleConfirmed = false,
                candlePatternQuality = "Netral"
            )
        }

        val enriched = enrichCandlesWithIndicators(candles)
        val last = enriched.last()
        val prev = enriched[enriched.size - 2]
        val currentPrice = last.close
        val atr = calculateAtr(candles, 14)
        val defaultSlPips = max(atr * 1.5, 15.0 / pipMultiplier)
        val defaultTp1Pips = defaultSlPips * 1.5
        val defaultTp2Pips = defaultSlPips * 2.5

        val rsi = last.rsi ?: 50.0
        val ema20 = last.ema20 ?: currentPrice
        val ema50 = last.ema50 ?: currentPrice

        var signalType = SignalType.HOLD
        var confidence = 50
        var reason = ""
        var indicatorsSummary = ""

        when (strategy) {
            StrategyType.TREND_MOMENTUM -> {
                val isBullishTrend = ema20 > ema50 && currentPrice > ema20
                val isBearishTrend = ema20 < ema50 && currentPrice < ema20

                if (isBullishTrend && rsi in 45.0..68.0) {
                    signalType = SignalType.BUY
                    confidence = (76 + ((68.0 - rsi) / 2.0).toInt()).coerceIn(75, 94)
                    reason = "EMA 20 golden cross above EMA 50 with sustained bullish momentum and healthy RSI (${String.format("%.1f", rsi)})."
                    indicatorsSummary = "EMA20: ${String.format("%.${decimals}f", ema20)} > EMA50: ${String.format("%.${decimals}f", ema50)}, RSI(14): ${String.format("%.1f", rsi)}"
                } else if (isBearishTrend && rsi in 32.0..55.0) {
                    signalType = SignalType.SELL
                    confidence = (78 + ((rsi - 32.0) / 2.0).toInt()).coerceIn(75, 93)
                    reason = "EMA 20 death cross below EMA 50 with strong downward trend pressure and bearish confirmation."
                    indicatorsSummary = "EMA20: ${String.format("%.${decimals}f", ema20)} < EMA50: ${String.format("%.${decimals}f", ema50)}, RSI(14): ${String.format("%.1f", rsi)}"
                } else {
                    signalType = SignalType.HOLD
                    confidence = 58
                    reason = "Market consolidating between EMA 20 and EMA 50. Waiting for clean trend confirmation."
                    indicatorsSummary = "RSI: ${String.format("%.1f", rsi)}, Trend: Consolidation"
                }
            }

            StrategyType.BREAKOUT_SCALPER -> {
                val upperBB = last.upperBollinger ?: (currentPrice * 1.01)
                val lowerBB = last.lowerBollinger ?: (currentPrice * 0.99)
                val volumeSpike = last.volume > (enriched.takeLast(10).map { it.volume }.average() * 1.3)

                if (currentPrice > upperBB && volumeSpike) {
                    signalType = SignalType.BUY
                    confidence = 88
                    reason = "High volume volatility breakout above Upper Bollinger Band (${String.format("%.${decimals}f", upperBB)})."
                    indicatorsSummary = "BB Upper Breakout + Vol Spike (${String.format("%.0f", last.volume)}), RSI: ${String.format("%.1f", rsi)}"
                } else if (currentPrice < lowerBB && volumeSpike) {
                    signalType = SignalType.SELL
                    confidence = 87
                    reason = "High volume breakdown below Lower Bollinger Band (${String.format("%.${decimals}f", lowerBB)})."
                    indicatorsSummary = "BB Lower Breakdown + Vol Spike (${String.format("%.0f", last.volume)}), RSI: ${String.format("%.1f", rsi)}"
                } else {
                    signalType = SignalType.HOLD
                    confidence = 55
                    reason = "Price oscillating within normal Bollinger Band channels."
                    indicatorsSummary = "BB Range: ${String.format("%.${decimals}f", lowerBB)} - ${String.format("%.${decimals}f", upperBB)}"
                }
            }

            StrategyType.SMC_ORDER_BLOCK -> {
                val swingHigh = enriched.takeLast(20).maxOf { it.high }
                val swingLow = enriched.takeLast(20).minOf { it.low }
                val orderBlockDemand = swingLow + (atr * 0.8)
                val orderBlockSupply = swingHigh - (atr * 0.8)

                if (currentPrice <= orderBlockDemand && (last.lowerWick > last.bodyHeight * 1.5)) {
                    signalType = SignalType.BUY
                    confidence = 92
                    reason = "Institutional Order Block mitigation at key demand zone (${String.format("%.${decimals}f", orderBlockDemand)}) with rejection wick."
                    indicatorsSummary = "SMC Bullish Order Block + Liquidity Sweep, ATR: ${String.format("%.${decimals}f", atr)}"
                } else if (currentPrice >= orderBlockSupply && (last.upperWick > last.bodyHeight * 1.5)) {
                    signalType = SignalType.SELL
                    confidence = 91
                    reason = "Institutional Supply Zone mitigation (${String.format("%.${decimals}f", orderBlockSupply)}) with upper rejection wick."
                    indicatorsSummary = "SMC Bearish Order Block + Liquidity Grab, ATR: ${String.format("%.${decimals}f", atr)}"
                } else {
                    signalType = SignalType.HOLD
                    confidence = 62
                    reason = "Price trading in premium/discount equilibrium. Awaiting institutional zone mitigation."
                    indicatorsSummary = "Demand: ${String.format("%.${decimals}f", orderBlockDemand)}, Supply: ${String.format("%.${decimals}f", orderBlockSupply)}"
                }
            }

            StrategyType.RSI_MEAN_REVERSION -> {
                if (rsi < 28.0 && last.close > prev.close) {
                    signalType = SignalType.BUY
                    confidence = 84
                    reason = "Extreme oversold RSI (${String.format("%.1f", rsi)}) with bullish divergence reversal candle."
                    indicatorsSummary = "RSI(14) Oversold: ${String.format("%.1f", rsi)}, Bullish Turn"
                } else if (rsi > 72.0 && last.close < prev.close) {
                    signalType = SignalType.SELL
                    confidence = 83
                    reason = "Extreme overbought RSI (${String.format("%.1f", rsi)}) with bearish reversal momentum."
                    indicatorsSummary = "RSI(14) Overbought: ${String.format("%.1f", rsi)}, Bearish Turn"
                } else {
                    signalType = SignalType.HOLD
                    confidence = 54
                    reason = "RSI in neutral mid-range (${String.format("%.1f", rsi)})."
                    indicatorsSummary = "RSI Neutral: ${String.format("%.1f", rsi)}"
                }
            }

            StrategyType.MULTI_CONFIRMATION_HYBRID -> {
                val emaCrossBullish = ema20 > ema50
                val rsiBullish = rsi in 48.0..66.0
                if (emaCrossBullish && rsiBullish && last.isBullish) {
                    signalType = SignalType.BUY
                    confidence = 95
                    reason = "Triple confirmation: Trend alignment + RSI momentum + AI price action confirmation."
                    indicatorsSummary = "EMA20/50 Bullish Cross + RSI ${String.format("%.1f", rsi)} + Bullish PA"
                } else if (!emaCrossBullish && rsi in 34.0..52.0 && !last.isBullish) {
                    signalType = SignalType.SELL
                    confidence = 94
                    reason = "Triple confirmation: Downward trend structure + Bearish momentum + AI resistance reject."
                    indicatorsSummary = "EMA20/50 Bearish Cross + RSI ${String.format("%.1f", rsi)} + Bearish PA"
                } else {
                    signalType = SignalType.HOLD
                    confidence = 60
                    reason = "Multi-factor filters require stronger confluence before triggering automated entry."
                    indicatorsSummary = "Confluence Score: 2/4 (Need 3+)"
                }
            }
        }

        // Detect Candle Confirmation
        val confirmationInfo = detectConfirmationCandle(candles, signalType, atr)

        val sl = if (signalType == SignalType.BUY) currentPrice - defaultSlPips else currentPrice + defaultSlPips
        val tp1 = if (signalType == SignalType.BUY) currentPrice + defaultTp1Pips else currentPrice - defaultTp1Pips
        val tp2 = if (signalType == SignalType.BUY) currentPrice + defaultTp2Pips else currentPrice - defaultTp2Pips

        return TradeSignal(
            id = UUID.randomUUID().toString(),
            pairSymbol = pairSymbol,
            type = signalType,
            strategyName = strategy.title,
            entryPrice = currentPrice,
            stopLoss = sl,
            takeProfit1 = tp1,
            takeProfit2 = tp2,
            riskRewardRatio = "1:2.5",
            confidenceScore = confidence,
            reasoning = if (confirmationInfo.isConfirmed && signalType != SignalType.HOLD) {
                "${confirmationInfo.patternName}: ${confirmationInfo.description} $reason"
            } else reason,
            keyIndicators = indicatorsSummary,
            isAIGenerated = true,
            confirmationCandle = confirmationInfo.patternName,
            isCandleConfirmed = confirmationInfo.isConfirmed,
            candlePatternQuality = confirmationInfo.quality,
            candleTimeframe = "H1 / M15"
        )
    }
}
