package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.CandleStick
import com.example.data.model.DefaultForexPairs
import com.example.data.model.StrategyType
import com.example.domain.engine.BacktestEngine
import com.example.domain.engine.MarketSimulator
import com.example.domain.engine.TechnicalAnalysis
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context verifies app name`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Kembangan Bot", appName)
    }

    @Test
    fun `technical analysis calculates indicators correctly`() {
        val candles = (1..30).map { i ->
            val price = 1.0800 + (i * 0.0005)
            CandleStick(
                timestamp = System.currentTimeMillis() - (30 - i) * 60000L,
                open = price - 0.0002,
                high = price + 0.0004,
                low = price - 0.0004,
                close = price,
                volume = 1000.0 + i * 50
            )
        }
        val enriched = TechnicalAnalysis.enrichCandlesWithIndicators(candles)
        val last = enriched.last()

        assertNotNull(last.ema20)
        assertNotNull(last.rsi)
        assertNotNull(last.upperBollinger)
        assertNotNull(last.lowerBollinger)
        assertTrue(last.rsi!! in 0.0..100.0)
    }

    @Test
    fun `market simulator generates ticks and updates candles`() {
        val simulator = MarketSimulator()
        val initialPairs = simulator.pairs.value
        assertEquals(8, initialPairs.size)

        val updatedPairs = simulator.tick()
        assertEquals(8, updatedPairs.size)
        assertNotNull(updatedPairs.firstOrNull { it.symbol == "EUR/USD" })
    }

    @Test
    fun `backtest engine runs successfully on historical candles`() {
        val pair = DefaultForexPairs.pairs.first { it.symbol == "EUR/USD" }
        val candles = (1..50).map { i ->
            val price = 1.0800 + (i * 0.0003)
            CandleStick(
                timestamp = System.currentTimeMillis() - (50 - i) * 60000L,
                open = price - 0.0002,
                high = price + 0.0005,
                low = price - 0.0003,
                close = price,
                volume = 1500.0
            )
        }
        val result = BacktestEngine.runBacktest(pair, StrategyType.TREND_MOMENTUM, candles)
        assertNotNull(result)
        assertEquals(StrategyType.TREND_MOMENTUM.title, result.strategyName)
        assertEquals("EUR/USD", result.pairSymbol)
    }
}
