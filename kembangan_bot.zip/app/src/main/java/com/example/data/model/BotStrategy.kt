package com.example.data.model

enum class StrategyType(val title: String, val badge: String) {
    TREND_MOMENTUM("Trend Momentum AI", "Trend"),
    BREAKOUT_SCALPER("Breakout Scalper AI", "Scalp"),
    SMC_ORDER_BLOCK("Smart Money (SMC) AI", "SMC"),
    RSI_MEAN_REVERSION("RSI Mean Reversion", "Reversal"),
    MULTI_CONFIRMATION_HYBRID("Deep Gemini Hybrid AI", "Gemini AI")
}

data class BotStrategyConfig(
    val strategyType: StrategyType = StrategyType.TREND_MOMENTUM,
    val isAutoTradingEnabled: Boolean = false,
    val selectedPairs: List<String> = listOf("EUR/USD", "GBP/USD", "USD/JPY", "XAU/USD"),
    val lotSize: Double = 0.10, // Lot size per trade
    val maxDrawdownPercent: Double = 10.0, // Circuit breaker max drawdown %
    val maxDailyLossPercent: Double = 5.0, // Max daily loss %
    val maxRiskPerTradePercent: Double = 2.0, // 2% risk
    val riskRewardRatio: Double = 2.0, // 1:2 RR
    val stopLossPips: Double = 25.0,
    val takeProfitPips: Double = 50.0,
    val useTrailingStop: Boolean = true,
    val trailingStopPips: Double = 15.0,
    val maxOpenTrades: Int = 3,
    val minConfidenceThreshold: Int = 75, // Only trade >= 75% confidence
    val scanIntervalSeconds: Int = 5,
    val circuitBreakerTriggered: Boolean = false,
    val isSignalNotificationEnabled: Boolean = true,
    val notifyOnlyOnCandleConfirmation: Boolean = true,
    val enableNotificationSound: Boolean = true,
    val enableNotificationVibration: Boolean = true,
    val minNotificationConfidence: Int = 75
)
