package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.OrderType
import com.example.data.model.ForexPair
import com.example.ui.theme.BearishCandle
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BullishCandle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun TradeDialog(
    pair: ForexPair,
    initialOrderType: OrderType = OrderType.BUY,
    onDismiss: () -> Unit,
    onExecuteTrade: (OrderType, Double, Double, Double) -> Unit
) {
    var orderType by remember { mutableStateOf(initialOrderType) }
    var lotSize by remember { mutableDoubleStateOf(0.10) }
    var slPips by remember { mutableDoubleStateOf(25.0) }
    var tpPips by remember { mutableDoubleStateOf(50.0) }

    val currentPrice = if (orderType == OrderType.BUY) pair.currentAsk else pair.currentBid
    val pipVal = 1.0 / pair.pipMultiplier
    val calculatedSL = if (orderType == OrderType.BUY) currentPrice - (slPips * pipVal) else currentPrice + (slPips * pipVal)
    val calculatedTP = if (orderType == OrderType.BUY) currentPrice + (tpPips * pipVal) else currentPrice - (tpPips * pipVal)

    val estimatedProfit = tpPips * lotSize * 10.0
    val estimatedLoss = slPips * lotSize * 10.0
    val requiredMargin = lotSize * 1000.0

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header: Pair & Live Price
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Eksekusi Order ${pair.symbol}",
                            color = TextPrimary,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Spread: ${String.format("%.1f", pair.spread)} pips",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }

                // Buy / Sell Selector Tabs
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(DarkSurfaceElevated)
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (orderType == OrderType.BUY) BullishCandle else Color.Transparent)
                            .clickable { orderType = OrderType.BUY }
                            .padding(vertical = 10.dp)
                            .testTag("select_buy_tab"),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                "BUY (LONG)",
                                color = if (orderType == OrderType.BUY) Color.Black else TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                pair.formattedAsk,
                                color = if (orderType == OrderType.BUY) Color.Black else BullishCandle,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (orderType == OrderType.SELL) BearishCandle else Color.Transparent)
                            .clickable { orderType = OrderType.SELL }
                            .padding(vertical = 10.dp)
                            .testTag("select_sell_tab"),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                "SELL (SHORT)",
                                color = if (orderType == OrderType.SELL) Color.White else TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                pair.formattedPrice,
                                color = if (orderType == OrderType.SELL) Color.White else BearishCandle,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                // Lot Size Stepper
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Volume Lot", color = TextSecondary, fontSize = 12.sp)
                        Text("${String.format("%.2f", lotSize)} Lot (Margin: $${String.format("%.0f", requiredMargin)})", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        listOf(0.01, 0.05, 0.10, 0.50, 1.00).forEach { preset ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (lotSize == preset) CyanAccent.copy(alpha = 0.2f) else DarkSurfaceElevated)
                                    .border(1.dp, if (lotSize == preset) CyanAccent else BorderSubtle, RoundedCornerShape(6.dp))
                                    .clickable { lotSize = preset }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    String.format("%.2f", preset),
                                    color = if (lotSize == preset) CyanAccent else TextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }

                // Risk & Profit Parameters (SL & TP)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Stop Loss Box
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .background(DarkSurfaceElevated, RoundedCornerShape(8.dp))
                            .border(1.dp, BearishCandle.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Text("Stop Loss (SL)", color = BearishCandle, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("${slPips.toInt()} Pips ($${String.format("%.2f", estimatedLoss)})", color = TextSecondary, fontSize = 11.sp)
                        Text(
                            String.format("%.${pair.decimals}f", calculatedSL),
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            IconButton(onClick = { if (slPips > 10) slPips -= 5 }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Remove, contentDescription = null, tint = TextSecondary)
                            }
                            IconButton(onClick = { slPips += 5 }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Add, contentDescription = null, tint = TextSecondary)
                            }
                        }
                    }

                    // Take Profit Box
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .background(DarkSurfaceElevated, RoundedCornerShape(8.dp))
                            .border(1.dp, BullishCandle.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Text("Take Profit (TP)", color = BullishCandle, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("${tpPips.toInt()} Pips (+$${String.format("%.2f", estimatedProfit)})", color = TextSecondary, fontSize = 11.sp)
                        Text(
                            String.format("%.${pair.decimals}f", calculatedTP),
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            IconButton(onClick = { if (tpPips > 10) tpPips -= 5 }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Remove, contentDescription = null, tint = TextSecondary)
                            }
                            IconButton(onClick = { tpPips += 5 }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Add, contentDescription = null, tint = TextSecondary)
                            }
                        }
                    }
                }

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Batal", color = TextSecondary)
                    }

                    Button(
                        onClick = {
                            onExecuteTrade(orderType, lotSize, slPips, tpPips)
                            onDismiss()
                        },
                        modifier = Modifier
                            .weight(1.8f)
                            .testTag("confirm_order_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (orderType == OrderType.BUY) BullishCandle else BearishCandle,
                            contentColor = if (orderType == OrderType.BUY) Color.Black else Color.White
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            "Konfirmasi ${orderType.name}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }
}
