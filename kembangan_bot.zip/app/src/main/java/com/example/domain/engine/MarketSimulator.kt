package com.example.domain.engine

import com.example.data.model.CandleStick
import com.example.data.model.DefaultForexPairs
import com.example.data.model.ForexPair
import com.example.data.model.TimeFrame
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Random
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class MarketSimulator {
    private val random = Random()
    private val _pairs = MutableStateFlow<List<ForexPair>>(DefaultForexPairs.pairs)
    val pairs: StateFlow<List<ForexPair>> = _pairs.asStateFlow()

    // Map: PairSymbol -> Map: TimeFrame -> List<CandleStick>
    private val candlesMap = HashMap<String, MutableMap<TimeFrame, MutableList<CandleStick>>>()

    init {
        // Initialize candle history for all pairs and timeframes
        DefaultForexPairs.pairs.forEach { pair ->
            val tfMap = HashMap<TimeFrame, MutableList<CandleStick>>()
            TimeFrame.entries.forEach { tf ->
                tfMap[tf] = generateInitialCandles(pair, tf, count = 60).toMutableList()
            }
            candlesMap[pair.symbol] = tfMap
        }
    }

    private fun generateInitialCandles(pair: ForexPair, timeFrame: TimeFrame, count: Int): List<CandleStick> {
        val list = ArrayList<CandleStick>()
        var basePrice = pair.currentBid
        val now = System.currentTimeMillis()
        val intervalMs = timeFrame.minutes * 60 * 1000L
        val volatility = basePrice * 0.0015

        for (i in (count - 1) downTo 0) {
            val candleTime = now - (i * intervalMs)
            val trendDrift = (random.nextDouble() - 0.48) * volatility
            val open = basePrice
            val close = open + trendDrift
            val high = max(open, close) + (random.nextDouble() * volatility * 0.7)
            val low = min(open, close) - (random.nextDouble() * volatility * 0.7)
            val volume = 1500.0 + random.nextDouble() * 3500.0

            list.add(
                CandleStick(
                    timestamp = candleTime,
                    open = open,
                    high = high,
                    low = low,
                    close = close,
                    volume = volume
                )
            )
            basePrice = close
        }
        return TechnicalAnalysis.enrichCandlesWithIndicators(list)
    }

    fun getCandles(symbol: String, timeFrame: TimeFrame): List<CandleStick> {
        val tfMap = candlesMap[symbol] ?: return emptyList()
        val raw = tfMap[timeFrame] ?: return emptyList()
        return TechnicalAnalysis.enrichCandlesWithIndicators(raw)
    }

    fun tick(): List<ForexPair> {
        val updatedPairs = _pairs.value.map { pair ->
            // Simulate realistic pip movement
            val pip = 1.0 / pair.pipMultiplier
            val deltaPips = (random.nextDouble() - 0.49) * 2.5
            val priceChange = deltaPips * pip
            val newBid = max(0.0001, pair.currentBid + priceChange)
            val spreadVal = pair.spreadPips * pip
            val newAsk = newBid + spreadVal

            val newHigh = max(pair.high24h, newBid)
            val newLow = min(pair.low24h, newBid)
            val baseDayRef = (pair.high24h + pair.low24h) / 2.0
            val changePercent = ((newBid - baseDayRef) / baseDayRef) * 100.0

            // Update latest candle for M1
            updateLatestCandle(pair.symbol, newBid)

            pair.copy(
                currentBid = newBid,
                currentAsk = newAsk,
                high24h = newHigh,
                low24h = newLow,
                change24hPercent = changePercent
            )
        }
        _pairs.value = updatedPairs
        return updatedPairs
    }

    private fun updateLatestCandle(symbol: String, currentPrice: Double) {
        val tfMap = candlesMap[symbol] ?: return
        TimeFrame.entries.forEach { tf ->
            val list = tfMap[tf] ?: return@forEach
            if (list.isEmpty()) return@forEach
            val last = list.last()
            val now = System.currentTimeMillis()
            val intervalMs = tf.minutes * 60 * 1000L

            if (now - last.timestamp >= intervalMs) {
                // Form new candle
                val newCandle = CandleStick(
                    timestamp = now,
                    open = last.close,
                    high = max(last.close, currentPrice),
                    low = min(last.close, currentPrice),
                    close = currentPrice,
                    volume = 100.0 + random.nextDouble() * 50.0
                )
                list.add(newCandle)
                if (list.size > 80) list.removeAt(0)
            } else {
                // Update active candle
                val updated = last.copy(
                    high = max(last.high, currentPrice),
                    low = min(last.low, currentPrice),
                    close = currentPrice,
                    volume = last.volume + (random.nextDouble() * 5.0)
                )
                list[list.size - 1] = updated
            }
        }
    }
}
