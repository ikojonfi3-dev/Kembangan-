package com.example.domain.engine

import com.example.data.local.BotLogDao
import com.example.data.local.BotLogEntity
import com.example.data.local.OrderType
import com.example.data.local.PositionStatus
import com.example.data.local.TradeDao
import com.example.data.local.TradePositionEntity
import com.example.data.model.AccountState
import com.example.data.model.BotStrategyConfig
import com.example.data.model.ForexPair
import com.example.data.model.PerformanceMetrics
import com.example.data.model.SignalType
import com.example.data.model.TimeFrame
import com.example.data.model.TradeSignal
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max

class BotEngine(
    private val tradeDao: TradeDao,
    private val botLogDao: BotLogDao,
    private val marketSimulator: MarketSimulator,
    private val scope: CoroutineScope
) {
    private val _strategyConfig = MutableStateFlow(BotStrategyConfig())
    val strategyConfig: StateFlow<BotStrategyConfig> = _strategyConfig.asStateFlow()

    private val _accountState = MutableStateFlow(AccountState())
    val accountState: StateFlow<AccountState> = _accountState.asStateFlow()

    private val _liveSignals = MutableStateFlow<List<TradeSignal>>(emptyList())
    val liveSignals: StateFlow<List<TradeSignal>> = _liveSignals.asStateFlow()

    private val _latestSignalAlert = MutableStateFlow<TradeSignal?>(null)
    val latestSignalAlert: StateFlow<TradeSignal?> = _latestSignalAlert.asStateFlow()

    var onNewConfirmedSignalCallback: ((TradeSignal) -> Unit)? = null

    // Cache of last notified signal signature per pair: "SYMBOL_TYPE_PATTERN" to timestamp
    private val lastNotifiedSignals = mutableMapOf<String, Long>()

    private val _performanceMetrics = MutableStateFlow(PerformanceMetrics())
    val performanceMetrics: StateFlow<PerformanceMetrics> = _performanceMetrics.asStateFlow()

    fun dismissSignalAlert() {
        _latestSignalAlert.value = null
    }

    fun triggerTestSignalNotification(customPair: String? = null) {
        val symbol = customPair ?: "XAU/USD"
        val testCandleStick = marketSimulator.getCandles(symbol, TimeFrame.H1)
        val sampleSignal = TechnicalAnalysis.generateBotSignal(
            pairSymbol = symbol,
            candles = testCandleStick,
            strategy = _strategyConfig.value.strategyType,
            pipMultiplier = if (symbol.contains("XAU") || symbol.contains("JPY")) 100.0 else 10000.0,
            decimals = if (symbol.contains("XAU") || symbol.contains("JPY")) 2 else 4
        ).copy(
            type = SignalType.BUY,
            confidenceScore = 92,
            confirmationCandle = "Bullish Engulfing Confirmation",
            isCandleConfirmed = true,
            candlePatternQuality = "Konfirmasi A+",
            reasoning = "Candle konfirmasi Bullish Engulfing menembus resisten kunci dengan volume institusional tinggi.",
            keyIndicators = "EMA20 > EMA50, RSI: 58.4, Rejection Supply Clear"
        )

        _latestSignalAlert.value = sampleSignal
        onNewConfirmedSignalCallback?.invoke(sampleSignal)

        scope.launch(Dispatchers.IO) {
            botLogDao.insertLog(
                BotLogEntity(
                    level = "SIGNAL_CONFIRM",
                    pairSymbol = sampleSignal.pairSymbol,
                    strategyName = sampleSignal.strategyName,
                    message = "🔔 [TEST ALERT] Candle Konfirmasi Terdeteksi: ${sampleSignal.confirmationCandle} (${sampleSignal.type.name} @ ${sampleSignal.formattedEntry})"
                )
            )
        }
    }

    fun updateConfig(config: BotStrategyConfig) {
        _strategyConfig.value = config
        scope.launch(Dispatchers.IO) {
            botLogDao.insertLog(
                BotLogEntity(
                    level = "INFO",
                    pairSymbol = "ALL",
                    strategyName = config.strategyType.title,
                    message = "Bot configuration updated: Auto-Trading = ${config.isAutoTradingEnabled}, Lot = ${config.lotSize}, Strategy = ${config.strategyType.badge}"
                )
            )
        }
    }

    fun toggleAutoTrading(enabled: Boolean) {
        val updated = _strategyConfig.value.copy(isAutoTradingEnabled = enabled)
        _strategyConfig.value = updated
        scope.launch(Dispatchers.IO) {
            botLogDao.insertLog(
                BotLogEntity(
                    level = if (enabled) "INFO" else "RISK",
                    pairSymbol = "ALL",
                    strategyName = updated.strategyType.title,
                    message = if (enabled) "🤖 AI Trading Bot ACTIVATED. Scanning currency pairs..." else "⏸️ AI Trading Bot PAUSED by user."
                )
            )
        }
    }

    suspend fun executeManualTrade(
        pair: ForexPair,
        orderType: OrderType,
        lotSize: Double,
        stopLoss: Double,
        takeProfit: Double,
        strategyTag: String = "MANUAL"
    ): Long {
        val entryPrice = if (orderType == OrderType.BUY) pair.currentAsk else pair.currentBid
        val marginPerLot = 1000.0 // approx standard margin requirement
        val requiredMargin = lotSize * marginPerLot

        if (_accountState.value.freeMargin < requiredMargin) {
            botLogDao.insertLog(
                BotLogEntity(
                    level = "RISK",
                    pairSymbol = pair.symbol,
                    strategyName = strategyTag,
                    message = "Trade rejected: Insufficient Free Margin (${String.format("%.2f", _accountState.value.freeMargin)} USD available)."
                )
            )
            return -1L
        }

        val position = TradePositionEntity(
            pairSymbol = pair.symbol,
            orderType = orderType,
            lotSize = lotSize,
            entryPrice = entryPrice,
            currentPrice = entryPrice,
            stopLoss = stopLoss,
            takeProfit = takeProfit,
            profitLoss = 0.0,
            pips = 0.0,
            status = PositionStatus.OPEN,
            isBotTrade = strategyTag != "MANUAL",
            strategyTag = strategyTag,
            trailingStopActive = _strategyConfig.value.useTrailingStop
        )

        val id = tradeDao.insertPosition(position)
        botLogDao.insertLog(
            BotLogEntity(
                level = "EXECUTION",
                pairSymbol = pair.symbol,
                strategyName = strategyTag,
                message = "Executed ${orderType.name} order for ${pair.symbol} | Lot: $lotSize @ ${String.format("%.${pair.decimals}f", entryPrice)} | SL: ${String.format("%.${pair.decimals}f", stopLoss)}, TP: ${String.format("%.${pair.decimals}f", takeProfit)}"
            )
        )
        return id
    }

    suspend fun closePositionManually(positionId: Long) {
        val position = tradeDao.getPositionById(positionId) ?: return
        val pair = marketSimulator.pairs.value.firstOrNull { it.symbol == position.pairSymbol }
        val currentPrice = if (pair != null) {
            if (position.orderType == OrderType.BUY) pair.currentBid else pair.currentAsk
        } else position.currentPrice

        val pipMultiplier = pair?.pipMultiplier ?: 10000.0
        val pipsDiff = if (position.orderType == OrderType.BUY) {
            (currentPrice - position.entryPrice) * pipMultiplier
        } else {
            (position.entryPrice - currentPrice) * pipMultiplier
        }
        val pnl = pipsDiff * position.lotSize * 10.0 // Standard pip value per 1 lot is ~$10

        val updated = position.copy(
            status = PositionStatus.CLOSED,
            closePrice = currentPrice,
            closeTime = System.currentTimeMillis(),
            profitLoss = pnl,
            pips = pipsDiff
        )
        tradeDao.updatePosition(updated)

        // Realize profit/loss to balance
        val newBalance = _accountState.value.balance + pnl
        _accountState.value = _accountState.value.copy(balance = newBalance)

        botLogDao.insertLog(
            BotLogEntity(
                level = "EXECUTION",
                pairSymbol = position.pairSymbol,
                strategyName = position.strategyTag,
                message = "Closed ${position.orderType.name} on ${position.pairSymbol} | Realized PnL: ${String.format("%+.2f", pnl)} USD (${String.format("%+.1f", pipsDiff)} pips)"
            )
        )
    }

    suspend fun processMarketTick(pairs: List<ForexPair>, openPositions: List<TradePositionEntity>) {
        val config = _strategyConfig.value
        val pairMap = pairs.associateBy { it.symbol }

        // 1. Update Open Positions & Check SL/TP Hits
        var totalFloatingPnL = 0.0
        var totalUsedMargin = 0.0

        for (pos in openPositions) {
            val pair = pairMap[pos.pairSymbol] ?: continue
            val currentPrice = if (pos.orderType == OrderType.BUY) pair.currentBid else pair.currentAsk
            val pipMult = pair.pipMultiplier

            val pips = if (pos.orderType == OrderType.BUY) {
                (currentPrice - pos.entryPrice) * pipMult
            } else {
                (pos.entryPrice - currentPrice) * pipMult
            }
            val pnl = pips * pos.lotSize * 10.0
            totalFloatingPnL += pnl
            totalUsedMargin += pos.lotSize * 1000.0

            // Check Take Profit hit
            var isTpHit = false
            var isSlHit = false

            if (pos.takeProfit > 0.0) {
                if (pos.orderType == OrderType.BUY && currentPrice >= pos.takeProfit) isTpHit = true
                if (pos.orderType == OrderType.SELL && currentPrice <= pos.takeProfit) isTpHit = true
            }

            // Check Stop Loss hit
            if (pos.stopLoss > 0.0) {
                if (pos.orderType == OrderType.BUY && currentPrice <= pos.stopLoss) isSlHit = true
                if (pos.orderType == OrderType.SELL && currentPrice >= pos.stopLoss) isSlHit = true
            }

            if (isTpHit) {
                val closed = pos.copy(
                    status = PositionStatus.TP_HIT,
                    closePrice = currentPrice,
                    closeTime = System.currentTimeMillis(),
                    profitLoss = pnl,
                    pips = pips
                )
                tradeDao.updatePosition(closed)
                _accountState.value = _accountState.value.copy(balance = _accountState.value.balance + pnl)
                botLogDao.insertLog(
                    BotLogEntity(
                        level = "EXECUTION",
                        pairSymbol = pos.pairSymbol,
                        strategyName = pos.strategyTag,
                        message = "🎯 TAKE PROFIT TRIGGERED on ${pos.pairSymbol}! Profit: +${String.format("%.2f", pnl)} USD (+${String.format("%.1f", pips)} pips)"
                    )
                )
            } else if (isSlHit) {
                val closed = pos.copy(
                    status = PositionStatus.SL_HIT,
                    closePrice = currentPrice,
                    closeTime = System.currentTimeMillis(),
                    profitLoss = pnl,
                    pips = pips
                )
                tradeDao.updatePosition(closed)
                _accountState.value = _accountState.value.copy(balance = _accountState.value.balance + pnl)
                botLogDao.insertLog(
                    BotLogEntity(
                        level = "RISK",
                        pairSymbol = pos.pairSymbol,
                        strategyName = pos.strategyTag,
                        message = "🛑 STOP LOSS TRIGGERED on ${pos.pairSymbol}. Loss: ${String.format("%.2f", pnl)} USD (${String.format("%.1f", pips)} pips)"
                    )
                )
            } else {
                // Trailing stop update if enabled
                var updatedSL = pos.stopLoss
                if (config.useTrailingStop && pips > config.trailingStopPips) {
                    val trailDistance = (config.trailingStopPips / pipMult)
                    if (pos.orderType == OrderType.BUY) {
                        val potentialSL = currentPrice - trailDistance
                        if (potentialSL > pos.stopLoss) updatedSL = potentialSL
                    } else {
                        val potentialSL = currentPrice + trailDistance
                        if (pos.stopLoss == 0.0 || potentialSL < pos.stopLoss) updatedSL = potentialSL
                    }
                }

                tradeDao.updatePosition(
                    pos.copy(
                        currentPrice = currentPrice,
                        profitLoss = pnl,
                        pips = pips,
                        stopLoss = updatedSL
                    )
                )
            }
        }

        // Update Account Equity & Margin
        val currentBalance = _accountState.value.balance
        val currentEquity = currentBalance + totalFloatingPnL
        _accountState.value = _accountState.value.copy(
            equity = currentEquity,
            usedMargin = totalUsedMargin
        )

        // Check Max Drawdown Circuit Breaker
        val peakBalance = max(_accountState.value.initialBalance, currentBalance)
        val currentDrawdownPercent = if (peakBalance > 0.0 && currentEquity < peakBalance) {
            ((peakBalance - currentEquity) / peakBalance) * 100.0
        } else {
            0.0
        }

        var isAutoTradingAllowed = config.isAutoTradingEnabled
        if (config.isAutoTradingEnabled && currentDrawdownPercent >= config.maxDrawdownPercent) {
            isAutoTradingAllowed = false
            _strategyConfig.value = config.copy(
                isAutoTradingEnabled = false,
                circuitBreakerTriggered = true
            )
            botLogDao.insertLog(
                BotLogEntity(
                    level = "RISK",
                    pairSymbol = "ALL",
                    strategyName = "CIRCUIT_BREAKER",
                    message = "⚠️ SAFETY CIRCUIT BREAKER: Max Drawdown Limit (${String.format("%.1f", config.maxDrawdownPercent)}%) reached (Current: ${String.format("%.1f", currentDrawdownPercent)}%)! Auto-trading halted to protect account."
                )
            )
        }

        // 2. Scan Signals for All Configured Pairs
        val updatedSignals = ArrayList<TradeSignal>()
        for (pair in pairs) {
            val candles = marketSimulator.getCandles(pair.symbol, TimeFrame.H1)
            val signal = TechnicalAnalysis.generateBotSignal(
                pairSymbol = pair.symbol,
                candles = candles,
                strategy = config.strategyType,
                pipMultiplier = pair.pipMultiplier,
                decimals = pair.decimals
            )
            updatedSignals.add(signal)

            // Check for Candle Confirmation Signal Notification
            if (config.isSignalNotificationEnabled &&
                signal.type != SignalType.HOLD &&
                signal.confidenceScore >= config.minNotificationConfidence &&
                (!config.notifyOnlyOnCandleConfirmation || signal.isCandleConfirmed)
            ) {
                val signalKey = "${pair.symbol}_${signal.type.name}_${signal.confirmationCandle}"
                val lastNotified = lastNotifiedSignals[signalKey] ?: 0L
                val now = System.currentTimeMillis()

                // Trigger notification if this confirmed pattern hasn't been notified recently
                if (now - lastNotified > 45000L) {
                    lastNotifiedSignals[signalKey] = now
                    _latestSignalAlert.value = signal
                    onNewConfirmedSignalCallback?.invoke(signal)

                    scope.launch(Dispatchers.IO) {
                        botLogDao.insertLog(
                            BotLogEntity(
                                level = "SIGNAL_CONFIRM",
                                pairSymbol = pair.symbol,
                                strategyName = signal.strategyName,
                                message = "🕯️ Candle Konfirmasi Entry [${signal.confirmationCandle}]: Sinyal ${signal.type.name} @ ${signal.formattedEntry} (TP: ${signal.formattedTP1}, SL: ${signal.formattedSL})"
                            )
                        )
                    }
                }
            }

            // Auto-Trade Trigger Check
            if (isAutoTradingAllowed &&
                config.selectedPairs.contains(pair.symbol) &&
                signal.type != SignalType.HOLD &&
                signal.confidenceScore >= config.minConfidenceThreshold
            ) {
                val currentOpenForPair = openPositions.count { it.pairSymbol == pair.symbol && it.status == PositionStatus.OPEN }
                val totalOpen = openPositions.size

                if (currentOpenForPair == 0 && totalOpen < config.maxOpenTrades) {
                    val orderType = if (signal.type == SignalType.BUY) OrderType.BUY else OrderType.SELL
                    executeManualTrade(
                        pair = pair,
                        orderType = orderType,
                        lotSize = config.lotSize,
                        stopLoss = signal.stopLoss,
                        takeProfit = signal.takeProfit1,
                        strategyTag = config.strategyType.badge
                    )
                }
            }
        }
        _liveSignals.value = updatedSignals
    }

    fun updateMetrics(closedTrades: List<TradePositionEntity>) {
        if (closedTrades.isEmpty()) {
            _performanceMetrics.value = PerformanceMetrics()
            return
        }

        val total = closedTrades.size
        val wins = closedTrades.count { it.profitLoss > 0 }
        val losses = closedTrades.count { it.profitLoss < 0 }
        val winRate = (wins.toDouble() / total) * 100.0
        val totalPnL = closedTrades.sumOf { it.profitLoss }

        val totalGain = closedTrades.filter { it.profitLoss > 0 }.sumOf { it.profitLoss }
        val totalLoss = abs(closedTrades.filter { it.profitLoss < 0 }.sumOf { it.profitLoss })
        val profitFactor = if (totalLoss > 0) totalGain / totalLoss else if (totalGain > 0) 9.99 else 0.0

        val best = closedTrades.maxOfOrNull { it.profitLoss } ?: 0.0
        val worst = closedTrades.minOfOrNull { it.profitLoss } ?: 0.0
        val avg = totalPnL / total

        _performanceMetrics.value = PerformanceMetrics(
            totalTrades = total,
            winningTrades = wins,
            losingTrades = losses,
            winRate = winRate,
            totalProfitLoss = totalPnL,
            profitFactor = profitFactor,
            bestTrade = best,
            worstTrade = worst,
            averageTrade = avg,
            maxDrawdownPercent = 4.2
        )
    }

    suspend fun resetDemoBalance() {
        tradeDao.clearAllTrades()
        botLogDao.clearLogs()
        _accountState.value = AccountState(
            initialBalance = 10000.0,
            balance = 10000.0,
            equity = 10000.0,
            usedMargin = 0.0
        )
        _performanceMetrics.value = PerformanceMetrics()
        botLogDao.insertLog(
            BotLogEntity(
                level = "INFO",
                pairSymbol = "ALL",
                strategyName = "SYSTEM",
                message = "Demo Trading Account balance reset to $10,000 USD."
            )
        )
    }
}
