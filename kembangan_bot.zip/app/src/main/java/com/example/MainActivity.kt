package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.local.OrderType
import com.example.data.model.SignalType
import com.example.data.model.TradeSignal
import com.example.ui.components.SignalAlertBanner
import com.example.ui.components.TradeDialog
import com.example.ui.screens.AiAdvisorScreen
import com.example.ui.screens.BotControlScreen
import com.example.ui.screens.ChartScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.PortfolioScreen
import com.example.ui.screens.SignalsScreen
import com.example.ui.theme.BearishCandle
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BullishCandle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.ForexAiTheme
import com.example.ui.theme.PurpleAi
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.ForexViewModel

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Dashboard : Screen("dashboard", "Dashboard", Icons.Default.Dashboard)
    object Chart : Screen("chart", "Grafik", Icons.Default.ShowChart)
    object Signals : Screen("signals", "Sinyal AI", Icons.Default.Bolt)
    object BotControl : Screen("bot_control", "Bot Trading", Icons.Default.SmartToy)
    object Portfolio : Screen("portfolio", "Portofolio", Icons.Default.AccountBalanceWallet)
    object AiAdvisor : Screen("ai_advisor", "AI Chat", Icons.Default.AutoAwesome)
}

class MainActivity : ComponentActivity() {
    private val viewModel: ForexViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ForexAiApp(viewModel = viewModel)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ForexAiApp(viewModel: ForexViewModel) {
    val context = LocalContext.current
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    ForexAiTheme {
        val navController = rememberNavController()
        val navBackStackEntry by navController.currentBackStackEntryAsState()
        val currentRoute = navBackStackEntry?.destination?.route ?: Screen.Dashboard.route

        val strategyConfig by viewModel.strategyConfig.collectAsState()
        val openPositions by viewModel.openPositions.collectAsState()
        val liveSignals by viewModel.liveSignals.collectAsState()
        val latestSignalAlert by viewModel.latestSignalAlert.collectAsState()
        val pairs by viewModel.pairs.collectAsState()

        var selectedTradeSignal by remember { mutableStateOf<TradeSignal?>(null) }

        val bottomNavItems = listOf(
            Screen.Dashboard,
            Screen.Chart,
            Screen.Signals,
            Screen.BotControl,
            Screen.Portfolio
        )

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = DarkBg,
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(CyanAccent),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SmartToy,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "Kembangan Bot",
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (strategyConfig.isAutoTradingEnabled) BullishCandle.copy(alpha = 0.2f) else DarkSurfaceElevated)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    if (strategyConfig.isAutoTradingEnabled) "LIVE AUTO" else "MANUAL",
                                    color = if (strategyConfig.isAutoTradingEnabled) BullishCandle else TextSecondary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = {
                                navController.navigate(Screen.AiAdvisor.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            modifier = Modifier
                                .padding(end = 8.dp)
                                .clip(CircleShape)
                                .background(if (currentRoute == Screen.AiAdvisor.route) PurpleAi else DarkSurfaceElevated)
                                .testTag("open_ai_advisor_topbar")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "AI Advisor",
                                tint = if (currentRoute == Screen.AiAdvisor.route) Color.White else PurpleAi,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = DarkSurface
                    )
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = DarkSurface,
                    tonalElevation = 4.dp
                ) {
                    bottomNavItems.forEach { screen ->
                        val selected = currentRoute == screen.route
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                if (currentRoute != screen.route) {
                                    navController.navigate(screen.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = {
                                if (screen == Screen.Signals && liveSignals.isNotEmpty()) {
                                    BadgedBox(
                                        badge = {
                                            Badge(containerColor = CyanAccent) {
                                                Text("${liveSignals.size}", color = Color.Black, fontSize = 9.sp)
                                            }
                                        }
                                    ) {
                                        Icon(screen.icon, contentDescription = screen.title)
                                    }
                                } else if (screen == Screen.Portfolio && openPositions.isNotEmpty()) {
                                    BadgedBox(
                                        badge = {
                                            Badge(containerColor = BullishCandle) {
                                                Text("${openPositions.size}", color = Color.Black, fontSize = 9.sp)
                                            }
                                        }
                                    ) {
                                        Icon(screen.icon, contentDescription = screen.title)
                                    }
                                } else {
                                    Icon(screen.icon, contentDescription = screen.title)
                                }
                            },
                            label = {
                                Text(
                                    screen.title,
                                    fontSize = 10.sp,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = CyanAccent,
                                selectedTextColor = CyanAccent,
                                indicatorColor = DarkSurfaceElevated,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            ),
                            modifier = Modifier.testTag("nav_item_${screen.route}")
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                NavHost(
                    navController = navController,
                    startDestination = Screen.Dashboard.route,
                    modifier = Modifier.fillMaxSize()
                ) {
                    composable(Screen.Dashboard.route) {
                        DashboardScreen(
                            viewModel = viewModel,
                            onNavigateToChart = { navController.navigate(Screen.Chart.route) },
                            onNavigateToSignals = { navController.navigate(Screen.Signals.route) }
                        )
                    }
                    composable(Screen.Chart.route) {
                        ChartScreen(viewModel = viewModel)
                    }
                    composable(Screen.Signals.route) {
                        SignalsScreen(viewModel = viewModel)
                    }
                    composable(Screen.BotControl.route) {
                        BotControlScreen(viewModel = viewModel)
                    }
                    composable(Screen.Portfolio.route) {
                        PortfolioScreen(viewModel = viewModel)
                    }
                    composable(Screen.AiAdvisor.route) {
                        AiAdvisorScreen(viewModel = viewModel)
                    }
                }

                // In-App Floating Signal Alert Banner
                SignalAlertBanner(
                    signal = latestSignalAlert,
                    onDismiss = { viewModel.dismissSignalAlert() },
                    onNavigateToChart = { symbol ->
                        val pair = pairs.firstOrNull { it.symbol == symbol }
                        if (pair != null) {
                            viewModel.selectPair(pair)
                        }
                        navController.navigate(Screen.Chart.route) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    onQuickExecute = { sig ->
                        selectedTradeSignal = sig
                    },
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 4.dp)
                )

                // Quick Trade Confirmation Dialog
                selectedTradeSignal?.let { sig ->
                    val pair = pairs.firstOrNull { it.symbol == sig.pairSymbol }
                    if (pair != null) {
                        TradeDialog(
                            pair = pair,
                            initialOrderType = if (sig.type == SignalType.BUY) OrderType.BUY else OrderType.SELL,
                            onDismiss = { selectedTradeSignal = null },
                            onExecuteTrade = { orderType, lot, sl, tp ->
                                viewModel.placeOrder(orderType, lot, sl, tp)
                                selectedTradeSignal = null
                            }
                        )
                    }
                }
            }
        }
    }
}
