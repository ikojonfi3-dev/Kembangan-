package com.example.data.model

enum class SignalType {
    BUY, SELL, HOLD
}

data class TradeSignal(
    val id: String,
    val pairSymbol: String,
    val type: SignalType,
    val strategyName: String,
    val entryPrice: Double,
    val stopLoss: Double,
    val takeProfit1: Double,
    val takeProfit2: Double,
    val riskRewardRatio: String,
    val confidenceScore: Int, // 0 - 100
    val reasoning: String,
    val keyIndicators: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isAIGenerated: Boolean = true,
    val confirmationCandle: String = "Bullish Engulfing",
    val isCandleConfirmed: Boolean = true,
    val candlePatternQuality: String = "Konfirmasi A+", // A+, A, B
    val candleTimeframe: String = "M15"
) {
    val isGold: Boolean get() = pairSymbol.contains("XAU", ignoreCase = true)
    val decimals: Int get() = if (isGold || pairSymbol.contains("JPY", ignoreCase = true)) 2 else 4
    val formattedEntry: String get() = String.format("%.${decimals}f", entryPrice)
    val formattedSL: String get() = String.format("%.${decimals}f", stopLoss)
    val formattedTP1: String get() = String.format("%.${decimals}f", takeProfit1)
    val formattedTP2: String get() = String.format("%.${decimals}f", takeProfit2)
}

