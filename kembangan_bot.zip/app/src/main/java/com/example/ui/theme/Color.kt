package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// High-tech Luxury Dark Fintech Palette
val DarkBg = Color(0xFF090D16)
val DarkSurface = Color(0xFF0F172A)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkSurfaceCard = Color(0xFF131D31)
val DarkSurfaceElevated = Color(0xFF1A263D)

// Neon & Brand Accents
val EmeraldProfit = Color(0xFF00E699)
val EmeraldProfitDark = Color(0xFF059669)
val EmeraldGlow = Color(0x3300E699)

val CoralLoss = Color(0xFFFF4D4D)
val CoralLossDark = Color(0xFFDC2626)
val CoralGlow = Color(0x33FF4D4D)

val CyanAccent = Color(0xFF00F0FF)
val CyanAccentDark = Color(0xFF0284C7)
val CyanGlow = Color(0x2600F0FF)

val GoldAccent = Color(0xFFFFB703)
val PurpleAi = Color(0xFF8B5CF6)

// Text & Borders
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)
val BorderSubtle = Color(0xFF24324D)
val BorderFocus = Color(0xFF38BDF8)

// Chart Specific Colors
val BullishCandle = Color(0xFF00E699)
val BearishCandle = Color(0xFFFF4D4D)
val Ema20Color = Color(0xFFFFB703)
val Ema50Color = Color(0xFF38BDF8)
val BollingerColor = Color(0x668B5CF6)
val BollingerFillColor = Color(0x158B5CF6)
val RsiLineColor = Color(0xFFC084FC)
