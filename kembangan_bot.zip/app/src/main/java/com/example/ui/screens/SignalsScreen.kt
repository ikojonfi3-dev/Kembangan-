package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SignalType
import com.example.ui.components.AiAnalysisDialog
import com.example.ui.components.SignalCard
import com.example.ui.theme.BearishCandle
import com.example.ui.theme.BullishCandle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.PurpleAi
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.ForexViewModel

enum class SignalFilter {
    ALL, BUY_ONLY, SELL_ONLY, HIGH_CONFIDENCE
}

@Composable
fun SignalsScreen(
    viewModel: ForexViewModel,
    modifier: Modifier = Modifier
) {
    val liveSignals by viewModel.liveSignals.collectAsState()
    val pairs by viewModel.pairs.collectAsState()
    val aiScanResult by viewModel.aiScanResult.collectAsState()

    var activeFilter by remember { mutableStateOf(SignalFilter.ALL) }

    val filteredSignals = remember(liveSignals, activeFilter) {
        when (activeFilter) {
            SignalFilter.ALL -> liveSignals
            SignalFilter.BUY_ONLY -> liveSignals.filter { it.type == SignalType.BUY }
            SignalFilter.SELL_ONLY -> liveSignals.filter { it.type == SignalType.SELL }
            SignalFilter.HIGH_CONFIDENCE -> liveSignals.filter { it.confidenceScore >= 85 }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header & Live Scanner Banner
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = PurpleAi
                    )
                    Text(
                        "AI Scanner & Trade Signals",
                        color = TextPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    "Algoritma AI menganalisis formasi price action, likuiditas SMC, indikator EMA & RSI secara real-time pada 8 pasangan mata uang utama.",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
            }
        }

        // Filter Chips Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(
                SignalFilter.ALL to "Semua (${liveSignals.size})",
                SignalFilter.BUY_ONLY to "BUY",
                SignalFilter.SELL_ONLY to "SELL",
                SignalFilter.HIGH_CONFIDENCE to "Akurasi ≥85%"
            ).forEach { (filter, label) ->
                val isSelected = activeFilter == filter
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) CyanAccent else DarkSurfaceElevated)
                        .clickable { activeFilter = filter }
                        .padding(horizontal = 12.dp, vertical = 7.dp)
                ) {
                    Text(
                        text = label,
                        color = if (isSelected) Color.Black else TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Signals List
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 16.dp)
        ) {
            if (filteredSignals.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "Tidak ada sinyal yang sesuai dengan filter saat ini.",
                            color = TextSecondary,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            items(filteredSignals) { signal ->
                SignalCard(
                    signal = signal,
                    onExecuteTrade = { viewModel.executeSignalDirectly(it) },
                    onDeepScanGemini = { symbol ->
                        val pair = pairs.firstOrNull { it.symbol == symbol } ?: pairs.first()
                        viewModel.scanWithGeminiAI(pair)
                    }
                )
            }
        }
    }

    aiScanResult?.let { result ->
        AiAnalysisDialog(scanResult = result, onDismiss = { viewModel.clearAiScan() })
    }
}
