package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CandleStick
import com.example.ui.theme.BearishCandle
import com.example.ui.theme.BollingerColor
import com.example.ui.theme.BollingerFillColor
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BullishCandle
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.Ema20Color
import com.example.ui.theme.Ema50Color
import com.example.ui.theme.RsiLineColor
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.max
import kotlin.math.min

@Composable
fun CandlestickChart(
    candles: List<CandleStick>,
    decimals: Int = 4,
    showIndicators: Boolean = true,
    modifier: Modifier = Modifier
) {
    if (candles.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(280.dp)
                .background(DarkSurfaceCard, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("Memuat data grafik candlestick...", color = TextSecondary, fontSize = 13.sp)
        }
        return
    }

    var selectedCandleIndex by remember { mutableStateOf<Int?>(null) }
    val displayCandles = remember(candles) { candles.takeLast(40) }

    val activeCandle = selectedCandleIndex?.let { idx ->
        if (idx in displayCandles.indices) displayCandles[idx] else displayCandles.lastOrNull()
    } ?: displayCandles.lastOrNull()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(DarkSurfaceCard, RoundedCornerShape(12.dp))
            .padding(8.dp)
    ) {
        // Chart Header Info: OHLC & Indicators Legend
        activeCandle?.let { c ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "O: ${String.format("%.${decimals}f", c.open)}",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                    Text(
                        "H: ${String.format("%.${decimals}f", c.high)}",
                        color = BullishCandle,
                        fontSize = 11.sp
                    )
                    Text(
                        "L: ${String.format("%.${decimals}f", c.low)}",
                        color = BearishCandle,
                        fontSize = 11.sp
                    )
                    Text(
                        "C: ${String.format("%.${decimals}f", c.close)}",
                        color = if (c.isBullish) BullishCandle else BearishCandle,
                        fontSize = 11.sp
                    )
                }

                if (showIndicators) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        c.ema20?.let {
                            Text(
                                "EMA20: ${String.format("%.${decimals}f", it)}",
                                color = Ema20Color,
                                fontSize = 10.sp
                            )
                        }
                        c.ema50?.let {
                            Text(
                                "EMA50: ${String.format("%.${decimals}f", it)}",
                                color = Ema50Color,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }

        // Main Candlestick Canvas
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(displayCandles) {
                        detectTapGestures { offset ->
                            val candleWidth = size.width / displayCandles.size
                            val index = (offset.x / candleWidth).toInt().coerceIn(0, displayCandles.size - 1)
                            selectedCandleIndex = index
                        }
                    }
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height
                val count = displayCandles.size

                val minPrice = displayCandles.minOf { it.low } * 0.9995
                val maxPrice = displayCandles.maxOf { it.high } * 1.0005
                val priceRange = max(0.0001, maxPrice - minPrice)

                val candleSlotWidth = canvasWidth / count
                val candleBodyWidth = candleSlotWidth * 0.65f

                // Draw Grid Lines (3 horizontal levels)
                for (i in 1..3) {
                    val y = canvasHeight * (i / 4f)
                    drawLine(
                        color = BorderSubtle.copy(alpha = 0.5f),
                        start = Offset(0f, y),
                        end = Offset(canvasWidth, y),
                        strokeWidth = 1f
                    )
                }

                // Draw Bollinger Bands Shading & Lines
                if (showIndicators) {
                    drawBollingerBands(displayCandles, minPrice, priceRange, candleSlotWidth, canvasHeight)
                }

                // Draw Candlesticks (Wick + Body)
                displayCandles.forEachIndexed { index, candle ->
                    val centerX = (index * candleSlotWidth) + (candleSlotWidth / 2f)

                    val openY = (canvasHeight - ((candle.open - minPrice) / priceRange * canvasHeight)).toFloat()
                    val closeY = (canvasHeight - ((candle.close - minPrice) / priceRange * canvasHeight)).toFloat()
                    val highY = (canvasHeight - ((candle.high - minPrice) / priceRange * canvasHeight)).toFloat()
                    val lowY = (canvasHeight - ((candle.low - minPrice) / priceRange * canvasHeight)).toFloat()

                    val candleColor = if (candle.isBullish) BullishCandle else BearishCandle

                    // Wick
                    drawLine(
                        color = candleColor,
                        start = Offset(centerX, highY),
                        end = Offset(centerX, lowY),
                        strokeWidth = 1.5.dp.toPx()
                    )

                    // Body
                    val topY = min(openY, closeY)
                    val bodyH = max(2.dp.toPx(), kotlin.math.abs(openY - closeY))
                    val leftX = centerX - (candleBodyWidth / 2f)

                    drawRect(
                        color = candleColor,
                        topLeft = Offset(leftX, topY),
                        size = Size(candleBodyWidth, bodyH)
                    )
                }

                // Draw EMA 20 & EMA 50 Lines
                if (showIndicators) {
                    drawIndicatorLine(
                        candles = displayCandles,
                        extractor = { it.ema20 },
                        minPrice = minPrice,
                        priceRange = priceRange,
                        candleSlotWidth = candleSlotWidth,
                        canvasHeight = canvasHeight,
                        color = Ema20Color
                    )
                    drawIndicatorLine(
                        candles = displayCandles,
                        extractor = { it.ema50 },
                        minPrice = minPrice,
                        priceRange = priceRange,
                        candleSlotWidth = candleSlotWidth,
                        canvasHeight = canvasHeight,
                        color = Ema50Color
                    )
                }

                // Draw Selected Crosshair Line if touched
                selectedCandleIndex?.let { idx ->
                    if (idx in displayCandles.indices) {
                        val crossX = (idx * candleSlotWidth) + (candleSlotWidth / 2f)
                        drawLine(
                            color = TextSecondary.copy(alpha = 0.6f),
                            start = Offset(crossX, 0f),
                            end = Offset(crossX, canvasHeight),
                            strokeWidth = 1.dp.toPx(),
                            pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(8f, 8f))
                        )
                    }
                }
            }
        }

        // Sub-chart: RSI (14) Indicator Panel
        if (showIndicators) {
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("RSI (14)", color = TextSecondary, fontSize = 10.sp)
                activeCandle?.rsi?.let { r ->
                    Text(
                        String.format("%.1f", r),
                        color = when {
                            r >= 70 -> BearishCandle
                            r <= 30 -> BullishCandle
                            else -> RsiLineColor
                        },
                        fontSize = 10.sp
                    )
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(45.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val candleSlotWidth = w / displayCandles.size

                    // Draw 70 & 30 RSI guide levels
                    val y70 = h * (1f - (70f / 100f))
                    val y30 = h * (1f - (30f / 100f))

                    drawLine(
                        color = BearishCandle.copy(alpha = 0.3f),
                        start = Offset(0f, y70),
                        end = Offset(w, y70),
                        strokeWidth = 1f
                    )
                    drawLine(
                        color = BullishCandle.copy(alpha = 0.3f),
                        start = Offset(0f, y30),
                        end = Offset(w, y30),
                        strokeWidth = 1f
                    )

                    val rsiPath = Path()
                    var first = true

                    displayCandles.forEachIndexed { index, candle ->
                        val r = candle.rsi ?: 50.0
                        val x = (index * candleSlotWidth) + (candleSlotWidth / 2f)
                        val y = (h * (1f - (r.toFloat() / 100f))).coerceIn(0f, h)

                        if (first) {
                            rsiPath.moveTo(x, y)
                            first = false
                        } else {
                            rsiPath.lineTo(x, y)
                        }
                    }

                    drawPath(
                        path = rsiPath,
                        color = RsiLineColor,
                        style = Stroke(width = 1.5.dp.toPx())
                    )
                }
            }
        }
    }
}

private fun DrawScope.drawIndicatorLine(
    candles: List<CandleStick>,
    extractor: (CandleStick) -> Double?,
    minPrice: Double,
    priceRange: Double,
    candleSlotWidth: Float,
    canvasHeight: Float,
    color: Color
) {
    val path = Path()
    var started = false

    candles.forEachIndexed { index, candle ->
        val value = extractor(candle) ?: return@forEachIndexed
        val x = (index * candleSlotWidth) + (candleSlotWidth / 2f)
        val y = (canvasHeight - ((value - minPrice) / priceRange * canvasHeight)).toFloat()

        if (!started) {
            path.moveTo(x, y)
            started = true
        } else {
            path.lineTo(x, y)
        }
    }

    if (started) {
        drawPath(path = path, color = color, style = Stroke(width = 1.8.dp.toPx()))
    }
}

private fun DrawScope.drawBollingerBands(
    candles: List<CandleStick>,
    minPrice: Double,
    priceRange: Double,
    candleSlotWidth: Float,
    canvasHeight: Float
) {
    val upperPoints = ArrayList<Offset>()
    val lowerPoints = ArrayList<Offset>()

    candles.forEachIndexed { index, candle ->
        val u = candle.upperBollinger ?: return@forEachIndexed
        val l = candle.lowerBollinger ?: return@forEachIndexed
        val x = (index * candleSlotWidth) + (candleSlotWidth / 2f)
        val uy = (canvasHeight - ((u - minPrice) / priceRange * canvasHeight)).toFloat()
        val ly = (canvasHeight - ((l - minPrice) / priceRange * canvasHeight)).toFloat()
        upperPoints.add(Offset(x, uy))
        lowerPoints.add(Offset(x, ly))
    }

    if (upperPoints.size > 1 && lowerPoints.size > 1) {
        val bandPath = Path()
        bandPath.moveTo(upperPoints.first().x, upperPoints.first().y)
        upperPoints.forEach { bandPath.lineTo(it.x, it.y) }
        for (i in lowerPoints.indices.reversed()) {
            bandPath.lineTo(lowerPoints[i].x, lowerPoints[i].y)
        }
        bandPath.close()
        drawPath(path = bandPath, color = BollingerFillColor)

        // Draw upper & lower band borders
        val upperLine = Path().apply {
            moveTo(upperPoints.first().x, upperPoints.first().y)
            upperPoints.forEach { lineTo(it.x, it.y) }
        }
        val lowerLine = Path().apply {
            moveTo(lowerPoints.first().x, lowerPoints.first().y)
            lowerPoints.forEach { lineTo(it.x, it.y) }
        }
        drawPath(path = upperLine, color = BollingerColor, style = Stroke(width = 1f))
        drawPath(path = lowerLine, color = BollingerColor, style = Stroke(width = 1f))
    }
}
