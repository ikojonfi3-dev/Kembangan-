package com.example.data.model

data class ForexPair(
    val symbol: String,             // e.g. "EUR/USD"
    val name: String,               // e.g. "Euro / US Dollar"
    val baseCurrency: String,       // "EUR"
    val quoteCurrency: String,      // "USD"
    val currentBid: Double,
    val currentAsk: Double,
    val spreadPips: Double,
    val high24h: Double,
    val low24h: Double,
    val change24hPercent: Double,
    val decimals: Int = 4,
    val pipMultiplier: Double = 10000.0,
    val category: PairCategory = PairCategory.MAJOR
) {
    val spread: Double get() = (currentAsk - currentBid) * pipMultiplier
    val formattedPrice: String get() = String.format("%.${decimals}f", currentBid)
    val formattedAsk: String get() = String.format("%.${decimals}f", currentAsk)
    val formattedChange: String get() = String.format("%+.2f%%", change24hPercent)
    val isPositiveChange: Boolean get() = change24hPercent >= 0
}

enum class PairCategory {
    MAJOR, MINOR, COMMODITY, CRYPTO
}

object DefaultForexPairs {
    val pairs = listOf(
        ForexPair(
            symbol = "EUR/USD",
            name = "Euro / US Dollar",
            baseCurrency = "EUR",
            quoteCurrency = "USD",
            currentBid = 1.0864,
            currentAsk = 1.0866,
            spreadPips = 0.2,
            high24h = 1.0910,
            low24h = 1.0820,
            change24hPercent = 0.35,
            decimals = 4,
            pipMultiplier = 10000.0,
            category = PairCategory.MAJOR
        ),
        ForexPair(
            symbol = "GBP/USD",
            name = "British Pound / US Dollar",
            baseCurrency = "GBP",
            quoteCurrency = "USD",
            currentBid = 1.2945,
            currentAsk = 1.2948,
            spreadPips = 0.3,
            high24h = 1.2990,
            low24h = 1.2880,
            change24hPercent = 0.52,
            decimals = 4,
            pipMultiplier = 10000.0,
            category = PairCategory.MAJOR
        ),
        ForexPair(
            symbol = "USD/JPY",
            name = "US Dollar / Japanese Yen",
            baseCurrency = "USD",
            quoteCurrency = "JPY",
            currentBid = 154.32,
            currentAsk = 154.35,
            spreadPips = 0.3,
            high24h = 155.10,
            low24h = 153.80,
            change24hPercent = -0.42,
            decimals = 2,
            pipMultiplier = 100.0,
            category = PairCategory.MAJOR
        ),
        ForexPair(
            symbol = "XAU/USD",
            name = "Gold / US Dollar",
            baseCurrency = "XAU",
            quoteCurrency = "USD",
            currentBid = 2415.80,
            currentAsk = 2416.30,
            spreadPips = 5.0,
            high24h = 2435.00,
            low24h = 2398.50,
            change24hPercent = 1.15,
            decimals = 2,
            pipMultiplier = 10.0,
            category = PairCategory.COMMODITY
        ),
        ForexPair(
            symbol = "AUD/USD",
            name = "Australian Dollar / US Dollar",
            baseCurrency = "AUD",
            quoteCurrency = "USD",
            currentBid = 0.6580,
            currentAsk = 0.6582,
            spreadPips = 0.2,
            high24h = 0.6620,
            low24h = 0.6540,
            change24hPercent = 0.28,
            decimals = 4,
            pipMultiplier = 10000.0,
            category = PairCategory.MAJOR
        ),
        ForexPair(
            symbol = "USD/CAD",
            name = "US Dollar / Canadian Dollar",
            baseCurrency = "USD",
            quoteCurrency = "CAD",
            currentBid = 1.3740,
            currentAsk = 1.3743,
            spreadPips = 0.3,
            high24h = 1.3790,
            low24h = 1.3705,
            change24hPercent = -0.18,
            decimals = 4,
            pipMultiplier = 10000.0,
            category = PairCategory.MAJOR
        ),
        ForexPair(
            symbol = "USD/CHF",
            name = "US Dollar / Swiss Franc",
            baseCurrency = "USD",
            quoteCurrency = "CHF",
            currentBid = 0.8845,
            currentAsk = 0.8848,
            spreadPips = 0.3,
            high24h = 0.8890,
            low24h = 0.8810,
            change24hPercent = -0.22,
            decimals = 4,
            pipMultiplier = 10000.0,
            category = PairCategory.MAJOR
        ),
        ForexPair(
            symbol = "EUR/JPY",
            name = "Euro / Japanese Yen",
            baseCurrency = "EUR",
            quoteCurrency = "JPY",
            currentBid = 167.65,
            currentAsk = 167.69,
            spreadPips = 0.4,
            high24h = 168.40,
            low24h = 166.90,
            change24hPercent = -0.15,
            decimals = 2,
            pipMultiplier = 100.0,
            category = PairCategory.MINOR
        )
    )
}
