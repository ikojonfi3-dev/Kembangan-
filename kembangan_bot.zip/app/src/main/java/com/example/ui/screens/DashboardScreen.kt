package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.OrderType
import com.example.data.local.TradePositionEntity
import com.example.data.model.EconomicEvent
import com.example.data.model.ForexPair
import com.example.data.model.NewsImpact
import com.example.data.model.SignalType
import com.example.data.model.TradeSignal
import com.example.ui.components.AiAnalysisDialog
import com.example.ui.components.BotStatusCard
import com.example.ui.components.CandlestickChart
import com.example.ui.components.PairTickerBar
import com.example.ui.components.SignalCard
import com.example.ui.components.TradeDialog
import com.example.ui.theme.BearishCandle
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BullishCandle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.PurpleAi
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.ForexViewModel

@Composable
fun DashboardScreen(
    viewModel: ForexViewModel,
    onNavigateToChart: () -> Unit,
    onNavigateToSignals: () -> Unit,
    modifier: Modifier = Modifier
) {
    val pairs by viewModel.pairs.collectAsState()
    val selectedPair by viewModel.selectedPair.collectAsState()
    val currentCandles by viewModel.currentCandles.collectAsState()
    val strategyConfig by viewModel.strategyConfig.collectAsState()
    val accountState by viewModel.accountState.collectAsState()
    val liveSignals by viewModel.liveSignals.collectAsState()
    val openPositions by viewModel.openPositions.collectAsState()
    val economicEvents by viewModel.economicEvents.collectAsState()
    val aiScanResult by viewModel.aiScanResult.collectAsState()

    var showTradeDialog by remember { mutableStateOf(false) }
    var selectedOrderType by remember { mutableStateOf(OrderType.BUY) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Bot Status Card
        item {
            BotStatusCard(
                config = strategyConfig,
                accountState = accountState,
                onToggleAutoTrade = { viewModel.toggleAutoTrading(it) }
            )
        }

        // 2. Pair Ticker Bar
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "Pasar Forex Live",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                PairTickerBar(
                    pairs = pairs,
                    selectedPair = selectedPair,
                    onPairSelected = { viewModel.selectPair(it) }
                )
            }
        }

        // 3. Quick Chart & Actions for Selected Pair
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                selectedPair.symbol,
                                color = TextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "Bid: ${selectedPair.formattedPrice} | Ask: ${selectedPair.formattedAsk}",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }

                        Button(
                            onClick = { viewModel.scanWithGeminiAI(selectedPair) },
                            colors = ButtonDefaults.buttonColors(containerColor = PurpleAi),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                Icons.Default.AutoAwesome,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Scan AI", fontSize = 12.sp)
                        }
                    }

                    // Candlestick Chart View
                    CandlestickChart(
                        candles = currentCandles,
                        decimals = selectedPair.decimals,
                        showIndicators = true
                    )

                    // Quick Buy / Sell Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                selectedOrderType = OrderType.BUY
                                showTradeDialog = true
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("dashboard_quick_buy"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = BullishCandle,
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("BUY ${selectedPair.symbol}", fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                selectedOrderType = OrderType.SELL
                                showTradeDialog = true
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("dashboard_quick_sell"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = BearishCandle,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("SELL ${selectedPair.symbol}", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // 4. Open Positions Section (if any)
        if (openPositions.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Posisi Terbuka (${openPositions.size})",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    openPositions.forEach { pos ->
                        OpenPositionItem(
                            position = pos,
                            onClosePosition = { viewModel.closePosition(pos.id) }
                        )
                    }
                }
            }
        }

        // 5. Top AI Signals Header & List
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Sinyal AI Bot Terkini",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Lihat Semua",
                    color = CyanAccent,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { onNavigateToSignals() }
                )
            }
        }

        items(liveSignals.take(3)) { signal ->
            SignalCard(
                signal = signal,
                onExecuteTrade = { viewModel.executeSignalDirectly(it) },
                onDeepScanGemini = { symbol ->
                    val pair = pairs.firstOrNull { it.symbol == symbol } ?: selectedPair
                    viewModel.scanWithGeminiAI(pair)
                }
            )
        }

        // 6. Economic Calendar High Impact Events
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CalendarMonth,
                        contentDescription = null,
                        tint = GoldAccent,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        "Kalender Ekonomi & Berita Forex",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                economicEvents.take(2).forEach { event ->
                    EconomicEventCard(event = event)
                }
            }
        }
    }

    // Trade Dialog
    if (showTradeDialog) {
        TradeDialog(
            pair = selectedPair,
            initialOrderType = selectedOrderType,
            onDismiss = { showTradeDialog = false },
            onExecuteTrade = { type, lot, sl, tp ->
                viewModel.placeOrder(type, lot, sl, tp)
            }
        )
    }

    // AI Deep Analysis Dialog
    aiScanResult?.let { result ->
        AiAnalysisDialog(
            scanResult = result,
            onDismiss = { viewModel.clearAiScan() }
        )
    }
}

@Composable
fun OpenPositionItem(
    position: TradePositionEntity,
    onClosePosition: () -> Unit
) {
    val isBuy = position.orderType == OrderType.BUY
    val isWinning = position.isWinning
    val pnlColor = if (isWinning) BullishCandle else BearishCandle

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        position.pairSymbol,
                        color = TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isBuy) BullishCandle.copy(alpha = 0.2f) else BearishCandle.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            position.orderType.name,
                            color = if (isBuy) BullishCandle else BearishCandle,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    if (position.isBotTrade) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(PurpleAi.copy(alpha = 0.2f))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text("BOT", color = PurpleAi, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Text(
                    "Entry: ${String.format("%.4f", position.entryPrice)} | Lot: ${position.lotSize}",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        position.formattedProfit,
                        color = pnlColor,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        position.formattedPips,
                        color = pnlColor,
                        fontSize = 11.sp
                    )
                }

                IconButton(
                    onClick = onClosePosition,
                    modifier = Modifier
                        .size(28.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(BearishCandle.copy(alpha = 0.15f))
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Tutup Posisi",
                        tint = BearishCandle,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun EconomicEventCard(event: EconomicEvent) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (event.impact == NewsImpact.HIGH) BearishCandle.copy(alpha = 0.2f) else GoldAccent.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            "${event.currency} - ${event.impact.name}",
                            color = if (event.impact == NewsImpact.HIGH) BearishCandle else GoldAccent,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(event.time, color = TextSecondary, fontSize = 11.sp)
                }
                Text("Forecast: ${event.forecast} | Prev: ${event.previous}", color = TextSecondary, fontSize = 11.sp)
            }

            Text(event.title, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(
                "💡 AI Insight: ${event.aiInsight}",
                color = CyanAccent,
                fontSize = 11.sp,
                lineHeight = 15.sp
            )
        }
    }
}
