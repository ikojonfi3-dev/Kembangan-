package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class PositionStatus {
    OPEN, CLOSED, TP_HIT, SL_HIT
}

enum class OrderType {
    BUY, SELL
}

@Entity(tableName = "trade_positions")
data class TradePositionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val pairSymbol: String,
    val orderType: OrderType,
    val lotSize: Double,
    val entryPrice: Double,
    val currentPrice: Double,
    val stopLoss: Double,
    val takeProfit: Double,
    val closePrice: Double = 0.0,
    val profitLoss: Double = 0.0,
    val pips: Double = 0.0,
    val status: PositionStatus = PositionStatus.OPEN,
    val openTime: Long = System.currentTimeMillis(),
    val closeTime: Long = 0L,
    val isBotTrade: Boolean = false,
    val strategyTag: String = "MANUAL",
    val trailingStopActive: Boolean = false
) {
    val isWinning: Boolean get() = profitLoss > 0
    val formattedProfit: String get() = String.format("%+.2f USD", profitLoss)
    val formattedPips: String get() = String.format("%+.1f pips", pips)
}

@Entity(tableName = "bot_logs")
data class BotLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val level: String, // "SIGNAL", "EXECUTION", "RISK", "INFO"
    val pairSymbol: String,
    val message: String,
    val strategyName: String
)

@Entity(tableName = "saved_signals")
data class TradeSignalEntity(
    @PrimaryKey
    val id: String,
    val pairSymbol: String,
    val type: String,
    val strategyName: String,
    val entryPrice: Double,
    val stopLoss: Double,
    val takeProfit1: Double,
    val takeProfit2: Double,
    val confidenceScore: Int,
    val reasoning: String,
    val timestamp: Long
)
