package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TradeDao {
    @Query("SELECT * FROM trade_positions WHERE status = 'OPEN' ORDER BY openTime DESC")
    fun getOpenPositions(): Flow<List<TradePositionEntity>>

    @Query("SELECT * FROM trade_positions WHERE status != 'OPEN' ORDER BY closeTime DESC")
    fun getClosedPositions(): Flow<List<TradePositionEntity>>

    @Query("SELECT * FROM trade_positions ORDER BY openTime DESC")
    fun getAllPositions(): Flow<List<TradePositionEntity>>

    @Query("SELECT * FROM trade_positions WHERE id = :id LIMIT 1")
    suspend fun getPositionById(id: Long): TradePositionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPosition(position: TradePositionEntity): Long

    @Update
    suspend fun updatePosition(position: TradePositionEntity)

    @Query("DELETE FROM trade_positions")
    suspend fun clearAllTrades()
}

@Dao
interface BotLogDao {
    @Query("SELECT * FROM bot_logs ORDER BY timestamp DESC LIMIT 100")
    fun getRecentLogs(): Flow<List<BotLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: BotLogEntity)

    @Query("DELETE FROM bot_logs")
    suspend fun clearLogs()
}

@Dao
interface TradeSignalDao {
    @Query("SELECT * FROM saved_signals ORDER BY timestamp DESC")
    fun getSavedSignals(): Flow<List<TradeSignalEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSignal(signal: TradeSignalEntity)

    @Query("DELETE FROM saved_signals WHERE id = :id")
    suspend fun deleteSignal(id: String)
}
