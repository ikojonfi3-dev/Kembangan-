package com.example.domain.engine

import com.example.data.model.CandleStick
import com.example.data.model.ForexPair
import com.example.data.model.SignalType
import com.example.data.model.StrategyType
import kotlin.math.abs

data class BacktestResult(
    val strategyName: String,
    val pairSymbol: String,
    val totalTrades: Int,
    val winningTrades: Int,
    val losingTrades: Int,
    val winRate: Double,
    val initialBalance: Double = 10000.0,
    val finalBalance: Double,
    val totalProfitLoss: Double,
    val profitFactor: Double,
    val maxDrawdownPercent: Double,
    val tradeLogs: List<BacktestTradeLog>
)

data class BacktestTradeLog(
    val index: Int,
    val type: String,
    val entryPrice: Double,
    val exitPrice: Double,
    val profitLoss: Double,
    val pips: Double,
    val reason: String
)

object BacktestEngine {

    fun runBacktest(
        pair: ForexPair,
        strategy: StrategyType,
        candles: List<CandleStick>,
        lotSize: Double = 0.10
    ): BacktestResult {
        if (candles.size < 35) {
            return BacktestResult(
                strategyName = strategy.title,
                pairSymbol = pair.symbol,
                totalTrades = 0,
                winningTrades = 0,
                losingTrades = 0,
                winRate = 0.0,
                finalBalance = 10000.0,
                totalProfitLoss = 0.0,
                profitFactor = 0.0,
                maxDrawdownPercent = 0.0,
                tradeLogs = emptyList()
            )
        }

        var balance = 10000.0
        var peakBalance = balance
        var maxDrawdown = 0.0
        val tradeLogs = ArrayList<BacktestTradeLog>()
        var winCount = 0
        var lossCount = 0
        var totalGains = 0.0
        var totalLosses = 0.0

        val window = 30
        for (i in window until candles.size - 2) {
            val historicalSlice = candles.subList(0, i + 1)
            val signal = TechnicalAnalysis.generateBotSignal(
                pairSymbol = pair.symbol,
                candles = historicalSlice,
                strategy = strategy,
                pipMultiplier = pair.pipMultiplier,
                decimals = pair.decimals
            )

            if (signal.type != SignalType.HOLD && signal.confidenceScore >= 75) {
                val entryCandle = candles[i + 1]
                val entryPrice = entryCandle.open
                val sl = signal.stopLoss
                val tp = signal.takeProfit1

                // Simulate forward outcome over next 5 candles
                var exitPrice = entryPrice
                var isWin = false
                val pipMult = pair.pipMultiplier

                for (j in (i + 1) until kotlin.math.min(i + 6, candles.size)) {
                    val c = candles[j]
                    if (signal.type == SignalType.BUY) {
                        if (c.high >= tp) {
                            exitPrice = tp
                            isWin = true
                            break
                        } else if (c.low <= sl) {
                            exitPrice = sl
                            isWin = false
                            break
                        }
                    } else {
                        if (c.low <= tp) {
                            exitPrice = tp
                            isWin = true
                            break
                        } else if (c.high >= sl) {
                            exitPrice = sl
                            isWin = false
                            break
                        }
                    }
                    exitPrice = c.close
                }

                val pips = if (signal.type == SignalType.BUY) (exitPrice - entryPrice) * pipMult else (entryPrice - exitPrice) * pipMult
                val pnl = pips * lotSize * 10.0
                balance += pnl

                if (balance > peakBalance) peakBalance = balance
                val dd = ((peakBalance - balance) / peakBalance) * 100.0
                if (dd > maxDrawdown) maxDrawdown = dd

                if (pnl > 0) {
                    winCount++
                    totalGains += pnl
                } else {
                    lossCount++
                    totalLosses += abs(pnl)
                }

                tradeLogs.add(
                    BacktestTradeLog(
                        index = tradeLogs.size + 1,
                        type = signal.type.name,
                        entryPrice = entryPrice,
                        exitPrice = exitPrice,
                        profitLoss = pnl,
                        pips = pips,
                        reason = signal.reasoning
                    )
                )
            }
        }

        val totalTrades = winCount + lossCount
        val winRate = if (totalTrades > 0) (winCount.toDouble() / totalTrades) * 100.0 else 0.0
        val profitFactor = if (totalLosses > 0) totalGains / totalLosses else if (totalGains > 0) 9.99 else 0.0

        return BacktestResult(
            strategyName = strategy.title,
            pairSymbol = pair.symbol,
            totalTrades = totalTrades,
            winningTrades = winCount,
            losingTrades = lossCount,
            winRate = winRate,
            initialBalance = 10000.0,
            finalBalance = balance,
            totalProfitLoss = balance - 10000.0,
            profitFactor = profitFactor,
            maxDrawdownPercent = maxDrawdown,
            tradeLogs = tradeLogs
        )
    }
}
