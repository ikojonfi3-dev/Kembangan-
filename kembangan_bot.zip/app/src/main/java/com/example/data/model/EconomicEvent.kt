package com.example.data.model

enum class NewsImpact {
    HIGH, MEDIUM, LOW
}

data class EconomicEvent(
    val id: String,
    val title: String,
    val currency: String,
    val impact: NewsImpact,
    val time: String,
    val actual: String,
    val forecast: String,
    val previous: String,
    val aiInsight: String
)

object MockEconomicCalendar {
    val events = listOf(
        EconomicEvent(
            id = "nfp_01",
            title = "Non-Farm Employment Change (NFP)",
            currency = "USD",
            impact = NewsImpact.HIGH,
            time = "12:30 GMT",
            actual = "185K",
            forecast = "175K",
            previous = "142K",
            aiInsight = "Higher employment numbers strengthen the USD against major pairs. Favorable for USD/JPY long and EUR/USD short."
        ),
        EconomicEvent(
            id = "cpi_02",
            title = "Core CPI (MoM)",
            currency = "USD",
            impact = NewsImpact.HIGH,
            time = "12:30 GMT",
            actual = "0.2%",
            forecast = "0.2%",
            previous = "0.1%",
            aiInsight = "Inflation aligning with expectations supports Fed rate pause stance. Volatility expected around key resistance levels."
        ),
        EconomicEvent(
            id = "ecb_03",
            title = "ECB Monetary Policy Statement",
            currency = "EUR",
            impact = NewsImpact.HIGH,
            time = "13:15 GMT",
            actual = "3.50%",
            forecast = "3.50%",
            previous = "3.75%",
            aiInsight = "Dovish tone from ECB may create selling pressure on EUR pairs against USD and GBP."
        ),
        EconomicEvent(
            id = "boe_04",
            title = "BOE Interest Rate Decision",
            currency = "GBP",
            impact = NewsImpact.HIGH,
            time = "11:00 GMT",
            actual = "5.00%",
            forecast = "5.00%",
            previous = "5.25%",
            aiInsight = "Sterling maintains strength on hawkish guidance; monitor GBP/USD breakout above 1.2950."
        ),
        EconomicEvent(
            id = "boj_05",
            title = "BOJ Core CPI (YoY)",
            currency = "JPY",
            impact = NewsImpact.MEDIUM,
            time = "05:00 GMT",
            actual = "2.1%",
            forecast = "2.0%",
            previous = "1.9%",
            aiInsight = "Rising Japanese inflation increases probability of intervention and yen carry trade unwinding."
        )
    )
}
