package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.data.model.AccountState
import com.example.ui.components.BotStatusCard
import com.example.ui.theme.ForexAiTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [34])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun botStatus_screenshot() {
    composeTestRule.setContent {
      ForexAiTheme {
        BotStatusCard(
          config = com.example.data.model.BotStrategyConfig(isAutoTradingEnabled = true),
          accountState = AccountState(balance = 10000.0, equity = 10145.50),
          onToggleAutoTrade = {}
        )
      }
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/bot_status.png")
  }
}
