package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = EmeraldProfit,
    onPrimary = DarkBg,
    primaryContainer = DarkSurfaceElevated,
    onPrimaryContainer = EmeraldProfit,
    secondary = CyanAccent,
    onSecondary = DarkBg,
    secondaryContainer = DarkSurfaceVariant,
    onSecondaryContainer = CyanAccent,
    tertiary = GoldAccent,
    onTertiary = DarkBg,
    background = DarkBg,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    error = CoralLoss,
    onError = DarkBg,
    outline = BorderSubtle,
    outlineVariant = DarkSurfaceCard
)

@Composable
fun ForexAiTheme(
    darkTheme: Boolean = true, // Default to sleek dark trading terminal theme
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
